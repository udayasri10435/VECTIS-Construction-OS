import React, { useState } from 'react';
import { BimElement, RfiItem, SubmittalItem } from '../../types';
import { BimViewer3D } from './BimViewer3D';
import { 
  Layers, 
  AlertTriangle, 
  CheckCircle, 
  FileQuestion, 
  Box, 
  FileText, 
  ChevronRight,
  Maximize2,
  ExternalLink,
  Plus
} from 'lucide-react';

interface BimCoordinationViewProps {
  elements: BimElement[];
  rfis: RfiItem[];
  submittals: SubmittalItem[];
  onSelectRfi: (rfiId: string) => void;
  onCreateRfiFromClash: (clashElement: BimElement) => void;
  selectedElementId: string | null;
  onSelectElementId: (id: string | null) => void;
}

export const BimCoordinationView: React.FC<BimCoordinationViewProps> = ({
  elements,
  rfis,
  submittals,
  onSelectRfi,
  onCreateRfiFromClash,
  selectedElementId,
  onSelectElementId,
}) => {
  const [activeCategoryFilter, setActiveCategoryFilter] = useState<string>('All');
  const selectedElement = elements.find((e) => e.id === selectedElementId) || null;

  const clashingElements = elements.filter((e) => e.hasClash);

  const filteredElements = elements.filter((elem) => {
    if (activeCategoryFilter === 'All') return true;
    return elem.category === activeCategoryFilter;
  });

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <span>Engineering & VDC</span>
            <span aria-hidden="true">·</span>
            <span>Federated BIM LOD 400</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono text-slate-300">{elements.length} Model Objects</span>
          </div>
          <h2 className="text-xl font-bold text-slate-100 mt-1">3D BIM Clash Detection & Spatial Coordination</h2>
        </div>

        <div className="flex items-center gap-2">
          {clashingElements.length > 0 && (
            <div className="flex items-center gap-2 px-3 py-1.5 bg-red-950/60 border border-red-700/60 rounded-lg text-xs text-red-200">
              <AlertTriangle className="w-4 h-4 text-red-400 animate-pulse" />
              <span>
                <strong className="font-mono">{clashingElements.length}</strong> Critical Hard Clash Detected
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Main 3D Canvas Workspace */}
      <BimViewer3D
        elements={elements}
        rfis={rfis}
        selectedElementId={selectedElementId}
        onSelectElement={(elem) => onSelectElementId(elem ? elem.id : null)}
        onOpenRfi={(rfiId) => {
          if (rfiId.startsWith('new-for-')) {
            const elId = rfiId.replace('new-for-', '');
            const targetEl = elements.find((e) => e.id === elId);
            if (targetEl) onCreateRfiFromClash(targetEl);
          } else {
            onSelectRfi(rfiId);
          }
        }}
      />

      {/* Split Control & Clash Resolution Matrix */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left 2 Cols: Clash & Interference Registry */}
        <div className="lg:col-span-2 p-4 bg-slate-900/60 border border-slate-800 rounded-lg space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-red-400" />
              <h4 className="text-xs font-semibold text-slate-200 uppercase tracking-wider font-mono">
                Hard Clash & Interference Register
              </h4>
            </div>
            <span className="text-xs text-slate-400 font-mono">Tolerance: 0.25 inch</span>
          </div>

          <div className="space-y-2.5">
            {clashingElements.length === 0 ? (
              <div className="p-6 text-center text-slate-500 text-xs">
                Zero geometric collisions detected in current model federation.
              </div>
            ) : (
              clashingElements.map((elem) => {
                const linkedRfi = rfis.find((r) => r.id === elem.linkedRfiId);
                const isSelected = elem.id === selectedElementId;

                return (
                  <div
                    key={elem.id}
                    onClick={() => onSelectElementId(elem.id)}
                    className={`p-3.5 rounded-lg border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-red-950/40 border-red-500/80 ring-1 ring-red-500/30'
                        : 'bg-slate-950/80 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2 text-xs font-mono">
                          <span className="text-red-400 font-bold uppercase">{elem.category}</span>
                          <span className="text-slate-500">·</span>
                          <span className="text-slate-300 font-medium">{elem.guid}</span>
                          <span className="text-slate-500">·</span>
                          <span className="text-slate-400">{elem.grid}</span>
                        </div>
                        <h5 className="text-sm font-semibold text-slate-100 mt-1">
                          {elem.name}
                        </h5>
                        <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                          {elem.clashDescription}
                        </p>
                      </div>

                      <div className="flex sm:flex-col items-end gap-1.5 shrink-0" onClick={(e) => e.stopPropagation()}>
                        {linkedRfi ? (
                          <button
                            onClick={() => onSelectRfi(linkedRfi.id)}
                            className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-amber-300 bg-amber-950/60 border border-amber-700/60 rounded hover:bg-amber-900/60 transition-colors whitespace-nowrap"
                          >
                            <FileQuestion className="w-3.5 h-3.5" />
                            <span>{linkedRfi.number} ({linkedRfi.status})</span>
                          </button>
                        ) : (
                          <button
                            onClick={() => onCreateRfiFromClash(elem)}
                            className="flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded transition-colors whitespace-nowrap"
                          >
                            <Plus className="w-3.5 h-3.5" />
                            <span>Draft RFI from Collision</span>
                          </button>
                        )}
                        <button
                          onClick={() => onSelectElementId(elem.id)}
                          className="px-2 py-0.5 text-[11px] text-slate-400 hover:text-white"
                        >
                          Focus in 3D
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Right Col: Element Hierarchy & Inspector */}
        <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-lg space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-semibold text-slate-200 uppercase tracking-wider font-mono">
              Model Hierarchy & Status
            </h4>
            <span className="text-xs font-mono text-slate-400">{filteredElements.length} items</span>
          </div>

          {/* Quick Category Filter Bar */}
          <div className="flex items-center gap-1 p-0.5 bg-slate-950 border border-slate-800 rounded-md text-xs">
            {['All', 'structural', 'mep', 'modular_pod'].map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategoryFilter(cat)}
                className={`px-2 py-1 text-[11px] font-medium rounded transition-colors whitespace-nowrap ${
                  activeCategoryFilter === cat
                    ? 'bg-slate-800 text-slate-100 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {cat === 'all' ? 'All' : cat === 'modular_pod' ? 'Modular' : cat.toUpperCase()}
              </button>
            ))}
          </div>

          {/* Scrollable Element List */}
          <div className="max-h-[300px] overflow-y-auto space-y-1.5 pr-1 text-xs">
            {filteredElements.map((elem) => {
              const isSelected = elem.id === selectedElementId;

              return (
                <div
                  key={elem.id}
                  onClick={() => onSelectElementId(elem.id)}
                  className={`p-2 rounded border cursor-pointer transition-colors flex items-center justify-between ${
                    isSelected
                      ? 'bg-sky-950/60 border-sky-600/80 text-sky-200'
                      : elem.hasClash
                      ? 'bg-red-950/20 border-red-900/50 text-slate-300 hover:border-red-700/50'
                      : 'bg-slate-950/50 border-slate-800/80 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <div className="truncate pr-2">
                    <div className="font-medium truncate">{elem.name}</div>
                    <div className="text-[10px] text-slate-400 font-mono">
                      {elem.guid} · {elem.level}
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <span className={`text-[10px] font-medium px-1.5 py-0.5 rounded ${
                      elem.fabricationStatus === 'Inspected' ? 'bg-emerald-950 text-emerald-300' :
                      elem.fabricationStatus === 'Erected' ? 'bg-sky-950 text-sky-300' :
                      'bg-slate-800 text-slate-300'
                    }`}>
                      {elem.fabricationStatus}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
