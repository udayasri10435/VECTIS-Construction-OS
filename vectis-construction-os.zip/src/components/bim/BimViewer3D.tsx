import React, { useEffect, useRef, useState, useMemo } from 'react';
import * as THREE from 'three';
import { BimElement, RfiItem } from '../../types';
import { 
  Eye, 
  Layers, 
  AlertTriangle, 
  Maximize2, 
  RotateCcw, 
  Compass, 
  Sparkles,
  Info,
  CheckCircle2,
  FileQuestion,
  Filter
} from 'lucide-react';

interface BimViewer3DProps {
  elements: BimElement[];
  rfis: RfiItem[];
  selectedElementId: string | null;
  onSelectElement: (element: BimElement | null) => void;
  onOpenRfi?: (rfiId: string) => void;
}

export const BimViewer3D: React.FC<BimViewer3DProps> = ({
  elements,
  rfis,
  selectedElementId,
  onSelectElement,
  onOpenRfi,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [hoveredElement, setHoveredElement] = useState<BimElement | null>(null);
  
  // Viewport Settings
  const [clashMode, setClashMode] = useState(false);
  const [xrayMode, setXrayMode] = useState(false);
  const [selectedLevel, setSelectedLevel] = useState<string>('All');
  const [activeLayers, setActiveLayers] = useState<Record<string, boolean>>({
    structural: true,
    mep: true,
    modular_pod: true,
    facade: true,
    foundation: true,
  });

  // Three.js internal references
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const meshMapRef = useRef<Map<string, THREE.Mesh>>(new Map());
  const animationFrameIdRef = useRef<number | null>(null);

  // Orbit controls state
  const isDraggingRef = useRef(false);
  const isPanningRef = useRef(false);
  const previousMousePositionRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const cameraSphericalRef = useRef({ radius: 28, theta: Math.PI / 4, phi: Math.PI / 3.2 });
  const targetLookAtRef = useRef(new THREE.Vector3(0, 4, 0));

  // Count active clashes
  const clashesCount = useMemo(() => elements.filter(e => e.hasClash).length, [elements]);

  // Setup Three scene once
  useEffect(() => {
    if (!mountRef.current) return;
    const width = mountRef.current.clientWidth;
    const height = mountRef.current.clientHeight;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x090d16); // Deep slate canvas
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    rendererRef.current = renderer;

    mountRef.current.appendChild(renderer.domElement);

    // Subtle Grid Ground
    const gridHelper = new THREE.GridHelper(40, 40, 0x334155, 0x1e293b);
    gridHelper.position.y = -0.5;
    scene.add(gridHelper);

    // Directional Lighting
    const hemiLight = new THREE.HemisphereLight(0xffffff, 0x1e293b, 0.9);
    hemiLight.position.set(0, 50, 0);
    scene.add(hemiLight);

    const dirLight = new THREE.DirectionalLight(0xffffff, 1.4);
    dirLight.position.set(20, 40, 20);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width = 2048;
    dirLight.shadow.mapSize.height = 2048;
    scene.add(dirLight);

    const fillLight = new THREE.DirectionalLight(0x38bdf8, 0.4);
    fillLight.position.set(-20, 15, -20);
    scene.add(fillLight);

    // Initial camera position from spherical coordinates
    const updateCameraPosition = () => {
      const { radius, theta, phi } = cameraSphericalRef.current;
      camera.position.x = targetLookAtRef.current.x + radius * Math.sin(phi) * Math.sin(theta);
      camera.position.y = targetLookAtRef.current.y + radius * Math.cos(phi);
      camera.position.z = targetLookAtRef.current.z + radius * Math.sin(phi) * Math.cos(theta);
      camera.lookAt(targetLookAtRef.current);
    };
    updateCameraPosition();

    // Render loop
    let clock = new THREE.Clock();
    const animate = () => {
      animationFrameIdRef.current = requestAnimationFrame(animate);
      const elapsedTime = clock.getElapsedTime();

      // Subtle pulse for clash elements if clash mode is active
      meshMapRef.current.forEach((mesh) => {
        const elemData = mesh.userData as BimElement;
        if (elemData && elemData.hasClash && mesh.material instanceof THREE.MeshStandardMaterial) {
          const intensity = 0.5 + 0.5 * Math.sin(elapsedTime * 4);
          mesh.material.emissive = new THREE.Color(0xdc2626);
          mesh.material.emissiveIntensity = intensity * 0.7;
        }
      });

      renderer.render(scene, camera);
    };
    animate();

    // Resize handler
    const handleResize = () => {
      if (!mountRef.current || !renderer || !camera) return;
      const newWidth = mountRef.current.clientWidth;
      const newHeight = mountRef.current.clientHeight;
      camera.aspect = newWidth / newHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(newWidth, newHeight);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      if (animationFrameIdRef.current) {
        cancelAnimationFrame(animationFrameIdRef.current);
      }
      if (renderer.domElement && mountRef.current?.contains(renderer.domElement)) {
        mountRef.current.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, []);

  // Update Meshes when elements, layers, clashMode, or xrayMode change
  useEffect(() => {
    const scene = sceneRef.current;
    if (!scene) return;

    // Clear existing meshes
    meshMapRef.current.forEach((mesh) => {
      scene.remove(mesh);
      mesh.geometry.dispose();
      if (Array.isArray(mesh.material)) {
        mesh.material.forEach((m) => m.dispose());
      } else {
        mesh.material.dispose();
      }
    });
    meshMapRef.current.clear();

    elements.forEach((element) => {
      // Check layer visibility
      if (!activeLayers[element.category]) return;

      // Check level filter
      if (selectedLevel !== 'All' && element.level !== selectedLevel) return;

      const [sx, sy, sz] = element.size;
      const [px, py, pz] = element.position;

      let geometry: THREE.BufferGeometry;
      if (element.category === 'mep' && element.specs.includes('pipe')) {
        // Cylindrical pipe
        geometry = new THREE.CylinderGeometry(sx / 2, sx / 2, sy, 16);
      } else {
        geometry = new THREE.BoxGeometry(sx, sy, sz);
      }

      // Material appearance
      let baseColor = new THREE.Color(element.color || '#64748b');
      let opacity = 1.0;
      let transparent = false;
      let roughness = 0.4;
      let metalness = 0.3;

      if (element.category === 'facade') {
        opacity = xrayMode ? 0.15 : 0.45;
        transparent = true;
        roughness = 0.1;
        metalness = 0.8;
      } else if (xrayMode) {
        opacity = element.hasClash ? 1.0 : 0.25;
        transparent = true;
      }

      if (clashMode) {
        if (element.hasClash) {
          baseColor = new THREE.Color('#ef4444');
          opacity = 1.0;
          transparent = false;
        } else {
          baseColor = new THREE.Color('#334155');
          opacity = 0.2;
          transparent = true;
        }
      }

      const isSelected = element.id === selectedElementId;
      if (isSelected) {
        baseColor = new THREE.Color('#38bdf8'); // Highlight selected cyan
      }

      const material = new THREE.MeshStandardMaterial({
        color: baseColor,
        roughness,
        metalness,
        transparent,
        opacity,
        wireframe: false,
      });

      const mesh = new THREE.Mesh(geometry, material);
      mesh.position.set(px, py, pz);
      mesh.castShadow = !transparent;
      mesh.receiveShadow = true;
      mesh.userData = element;

      // Add wireframe edge helper for clean architectural CAD outline
      const edges = new THREE.EdgesGeometry(geometry);
      const lineMaterial = new THREE.LineBasicMaterial({
        color: isSelected ? 0x38bdf8 : element.hasClash && clashMode ? 0xff4444 : 0x0f172a,
        linewidth: 1,
        transparent: true,
        opacity: isSelected ? 0.9 : 0.4,
      });
      const wireframe = new THREE.LineSegments(edges, lineMaterial);
      mesh.add(wireframe);

      // Add 3D Pin / Marker if element has active RFI or Submittal
      if (element.linkedRfiId) {
        const pinGeo = new THREE.OctahedronGeometry(0.35);
        const pinMat = new THREE.MeshBasicMaterial({ 
          color: element.hasClash ? 0xef4444 : 0xf59e0b,
          wireframe: false 
        });
        const pinMesh = new THREE.Mesh(pinGeo, pinMat);
        pinMesh.position.set(0, sy / 2 + 0.6, 0);
        mesh.add(pinMesh);
      }

      scene.add(mesh);
      meshMapRef.current.set(element.id, mesh);
    });
  }, [elements, activeLayers, selectedLevel, clashMode, xrayMode, selectedElementId]);

  // Raycasting for Hover & Click selection
  const handlePointerMove = (event: React.PointerEvent<HTMLDivElement>) => {
    if (isDraggingRef.current || isPanningRef.current) return;
    if (!mountRef.current || !cameraRef.current || !sceneRef.current) return;

    const rect = mountRef.current.getBoundingClientRect();
    const x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
    const y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera(new THREE.Vector2(x, y), cameraRef.current);

    const meshes = Array.from(meshMapRef.current.values());
    const intersects = raycaster.intersectObjects(meshes);

    if (intersects.length > 0) {
      const topMesh = intersects[0].object as THREE.Mesh;
      const elemData = topMesh.userData as BimElement;
      setHoveredElement(elemData || null);
    } else {
      setHoveredElement(null);
    }
  };

  const handlePointerDown = (event: React.PointerEvent<HTMLDivElement>) => {
    if (event.button === 2 || event.shiftKey) {
      isPanningRef.current = true;
    } else if (event.button === 0) {
      isDraggingRef.current = true;
    }
    previousMousePositionRef.current = { x: event.clientX, y: event.clientY };
  };

  const handleGlobalPointerMove = (event: React.PointerEvent<HTMLDivElement>) => {
    const deltaX = event.clientX - previousMousePositionRef.current.x;
    const deltaY = event.clientY - previousMousePositionRef.current.y;
    previousMousePositionRef.current = { x: event.clientX, y: event.clientY };

    if (isDraggingRef.current && cameraRef.current) {
      // Orbit
      cameraSphericalRef.current.theta -= deltaX * 0.007;
      cameraSphericalRef.current.phi = Math.max(
        0.1,
        Math.min(Math.PI / 2 - 0.05, cameraSphericalRef.current.phi - deltaY * 0.007)
      );

      const { radius, theta, phi } = cameraSphericalRef.current;
      cameraRef.current.position.x = targetLookAtRef.current.x + radius * Math.sin(phi) * Math.sin(theta);
      cameraRef.current.position.y = targetLookAtRef.current.y + radius * Math.cos(phi);
      cameraRef.current.position.z = targetLookAtRef.current.z + radius * Math.sin(phi) * Math.cos(theta);
      cameraRef.current.lookAt(targetLookAtRef.current);
    } else if (isPanningRef.current && cameraRef.current) {
      // Pan
      const panSpeed = 0.025;
      const forward = new THREE.Vector3();
      cameraRef.current.getWorldDirection(forward);
      const right = new THREE.Vector3().crossVectors(forward, cameraRef.current.up).normalize();
      const up = new THREE.Vector3().crossVectors(right, forward).normalize();

      targetLookAtRef.current.addScaledVector(right, -deltaX * panSpeed);
      targetLookAtRef.current.addScaledVector(up, deltaY * panSpeed);

      const { radius, theta, phi } = cameraSphericalRef.current;
      cameraRef.current.position.x = targetLookAtRef.current.x + radius * Math.sin(phi) * Math.sin(theta);
      cameraRef.current.position.y = targetLookAtRef.current.y + radius * Math.cos(phi);
      cameraRef.current.position.z = targetLookAtRef.current.z + radius * Math.sin(phi) * Math.cos(theta);
      cameraRef.current.lookAt(targetLookAtRef.current);
    }
  };

  const handlePointerUp = (event: React.PointerEvent<HTMLDivElement>) => {
    const wasDragging = isDraggingRef.current || isPanningRef.current;
    isDraggingRef.current = false;
    isPanningRef.current = false;

    // Check if it was a quick click without dragging
    if (mountRef.current && cameraRef.current) {
      const rect = mountRef.current.getBoundingClientRect();
      const x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
      const y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

      const raycaster = new THREE.Raycaster();
      raycaster.setFromCamera(new THREE.Vector2(x, y), cameraRef.current);
      const meshes = Array.from(meshMapRef.current.values());
      const intersects = raycaster.intersectObjects(meshes);

      if (intersects.length > 0) {
        const topMesh = intersects[0].object as THREE.Mesh;
        const elemData = topMesh.userData as BimElement;
        onSelectElement(elemData);
      } else if (!wasDragging) {
        onSelectElement(null);
      }
    }
  };

  const handleWheel = (event: React.WheelEvent<HTMLDivElement>) => {
    event.preventDefault();
    if (!cameraRef.current) return;
    const zoomFactor = event.deltaY * 0.03;
    cameraSphericalRef.current.radius = Math.max(5, Math.min(80, cameraSphericalRef.current.radius + zoomFactor));

    const { radius, theta, phi } = cameraSphericalRef.current;
    cameraRef.current.position.x = targetLookAtRef.current.x + radius * Math.sin(phi) * Math.sin(theta);
    cameraRef.current.position.y = targetLookAtRef.current.y + radius * Math.cos(phi);
    cameraRef.current.position.z = targetLookAtRef.current.z + radius * Math.sin(phi) * Math.cos(theta);
    cameraRef.current.lookAt(targetLookAtRef.current);
  };

  // Preset Views
  const resetCamera = (theta = Math.PI / 4, phi = Math.PI / 3.2, radius = 28) => {
    if (!cameraRef.current) return;
    targetLookAtRef.current.set(0, 4, 0);
    cameraSphericalRef.current = { radius, theta, phi };
    cameraRef.current.position.x = radius * Math.sin(phi) * Math.sin(theta);
    cameraRef.current.position.y = 4 + radius * Math.cos(phi);
    cameraRef.current.position.z = radius * Math.sin(phi) * Math.cos(theta);
    cameraRef.current.lookAt(targetLookAtRef.current);
  };

  const toggleLayer = (layer: string) => {
    setActiveLayers((prev) => ({ ...prev, [layer]: !prev[layer] }));
  };

  const selectedElement = elements.find((e) => e.id === selectedElementId);
  const selectedElementRfi = rfis.find((r) => r.id === selectedElement?.linkedRfiId);

  return (
    <div className="relative w-full h-[620px] rounded-lg border border-slate-800 bg-slate-950 overflow-hidden flex flex-col">
      {/* 3D Canvas Viewport */}
      <div
        ref={mountRef}
        className="w-full h-full cursor-grab active:cursor-grabbing select-none"
        onPointerMove={(e) => {
          handlePointerMove(e);
          handleGlobalPointerMove(e);
        }}
        onPointerDown={handlePointerDown}
        onPointerUp={handlePointerUp}
        onWheel={handleWheel}
        onContextMenu={(e) => e.preventDefault()}
      />

      {/* Top Floating Control Bar */}
      <div className="absolute top-3 left-3 right-3 flex items-center justify-between pointer-events-none">
        {/* Layer & Filter Buttons */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-900/90 backdrop-blur-md border border-slate-800 rounded-lg pointer-events-auto shadow-lg">
          <button
            onClick={() => toggleLayer('structural')}
            className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap ${
              activeLayers.structural
                ? 'bg-slate-800 text-slate-100'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Structural
          </button>
          <button
            onClick={() => toggleLayer('mep')}
            className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap ${
              activeLayers.mep
                ? 'bg-sky-950/80 text-sky-300 border border-sky-800/60'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            MEP / HVAC
          </button>
          <button
            onClick={() => toggleLayer('modular_pod')}
            className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap ${
              activeLayers.modular_pod
                ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-800/60'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Modular Pods
          </button>
          <button
            onClick={() => toggleLayer('facade')}
            className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap ${
              activeLayers.facade
                ? 'bg-slate-800 text-slate-100'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Facade
          </button>
        </div>

        {/* Level Selector & Modes */}
        <div className="flex items-center gap-2 pointer-events-auto">
          {/* Level Filter */}
          <div className="flex items-center gap-1 px-2 py-1 bg-slate-900/90 backdrop-blur-md border border-slate-800 rounded-lg text-xs">
            <span className="text-slate-400 text-xs">Level:</span>
            <select
              value={selectedLevel}
              onChange={(e) => setSelectedLevel(e.target.value)}
              className="bg-transparent text-slate-200 font-medium text-xs focus:outline-none cursor-pointer"
            >
              <option value="All" className="bg-slate-900">All Levels</option>
              <option value="Level 1" className="bg-slate-900">Level 1</option>
              <option value="Level 2" className="bg-slate-900">Level 2</option>
              <option value="Level 3" className="bg-slate-900">Level 3</option>
              <option value="Roof" className="bg-slate-900">Roof</option>
            </select>
          </div>

          {/* Clash Inspection Mode Toggle */}
          <button
            onClick={() => setClashMode(!clashMode)}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg transition-colors border shadow-md whitespace-nowrap ${
              clashMode
                ? 'bg-red-950 text-red-300 border-red-700/80 ring-2 ring-red-500/20'
                : 'bg-slate-900/90 text-slate-300 border-slate-800 hover:bg-slate-800'
            }`}
          >
            <AlertTriangle className={`w-3.5 h-3.5 ${clashMode ? 'text-red-400 animate-pulse' : 'text-slate-400'}`} />
            <span>Clash Inspector</span>
            {clashesCount > 0 && (
              <span className="font-mono text-xs px-1.5 py-0.2 rounded bg-red-900/60 text-red-200 border border-red-700/40">
                {clashesCount}
              </span>
            )}
          </button>

          {/* Ghost / X-Ray Mode */}
          <button
            onClick={() => setXrayMode(!xrayMode)}
            className={`flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium rounded-lg transition-colors border ${
              xrayMode
                ? 'bg-amber-950/80 text-amber-300 border-amber-700/70'
                : 'bg-slate-900/90 text-slate-300 border-slate-800 hover:bg-slate-800'
            }`}
            title="X-Ray Ghost Mode for Internal MEP Inspection"
          >
            <Eye className="w-3.5 h-3.5" />
            <span>X-Ray</span>
          </button>
        </div>
      </div>

      {/* Camera Orientation Shortcuts (Bottom Left) */}
      <div className="absolute bottom-3 left-3 flex items-center gap-1 p-1 bg-slate-900/90 backdrop-blur-md border border-slate-800 rounded-lg pointer-events-auto shadow-md">
        <button
          onClick={() => resetCamera(Math.PI / 4, Math.PI / 3.2, 28)}
          className="px-2 py-1 text-xs text-slate-300 hover:text-white rounded hover:bg-slate-800 transition-colors whitespace-nowrap"
          title="Isometric View"
        >
          Isometric
        </button>
        <button
          onClick={() => resetCamera(0, 0.01, 32)}
          className="px-2 py-1 text-xs text-slate-300 hover:text-white rounded hover:bg-slate-800 transition-colors whitespace-nowrap"
          title="Plan / Top View"
        >
          Top Plan
        </button>
        <button
          onClick={() => resetCamera(0, Math.PI / 2, 28)}
          className="px-2 py-1 text-xs text-slate-300 hover:text-white rounded hover:bg-slate-800 transition-colors whitespace-nowrap"
          title="South Elevation"
        >
          South Elev
        </button>
        <button
          onClick={() => resetCamera(Math.PI / 2, Math.PI / 2, 28)}
          className="px-2 py-1 text-xs text-slate-300 hover:text-white rounded hover:bg-slate-800 transition-colors whitespace-nowrap"
          title="East Elevation"
        >
          East Elev
        </button>
      </div>

      {/* Navigation Help Cue (Bottom Center) */}
      <div className="absolute bottom-3 left-1/2 -translate-x-1/2 hidden md:flex items-center gap-3 px-3 py-1 bg-slate-900/80 backdrop-blur-sm border border-slate-800/80 rounded-full text-xs text-slate-400 pointer-events-none">
        <span>Left Drag: Orbit</span>
        <span>·</span>
        <span>Right / Shift Drag: Pan</span>
        <span>·</span>
        <span>Scroll: Zoom</span>
        <span>·</span>
        <span>Click: Inspect Element</span>
      </div>

      {/* Hover Info Tooltip (Above cursor area or Top Right) */}
      {hoveredElement && !selectedElement && (
        <div className="absolute top-16 right-3 p-3 bg-slate-900/95 backdrop-blur-md border border-slate-700/80 rounded-lg shadow-xl max-w-xs pointer-events-none">
          <div className="text-xs font-semibold text-slate-100 truncate">{hoveredElement.name}</div>
          <div className="flex items-center gap-1.5 text-xs text-slate-400 mt-1">
            <span className="font-mono text-slate-300">{hoveredElement.guid}</span>
            <span>·</span>
            <span>{hoveredElement.grid}</span>
          </div>
          {hoveredElement.hasClash && (
            <div className="mt-2 text-xs text-red-300 flex items-center gap-1">
              <AlertTriangle className="w-3.5 h-3.5 text-red-400" />
              <span>Active Clash with {hoveredElement.clashesWithGuid}</span>
            </div>
          )}
        </div>
      )}

      {/* Selected Element Inspector Drawer (Bottom Right / Side Panel) */}
      {selectedElement && (
        <div className="absolute bottom-3 right-3 w-84 p-4 bg-slate-900/95 backdrop-blur-md border border-sky-700/60 rounded-lg shadow-2xl pointer-events-auto">
          <div className="flex items-start justify-between">
            <div>
              <div className="text-xs text-sky-400 font-mono tracking-wide uppercase">
                {selectedElement.category} · {selectedElement.level}
              </div>
              <h4 className="text-sm font-semibold text-slate-100 mt-0.5 leading-snug">
                {selectedElement.name}
              </h4>
            </div>
            <button
              onClick={() => onSelectElement(null)}
              className="text-slate-400 hover:text-slate-100 text-xs px-1.5 py-0.5 rounded hover:bg-slate-800"
            >
              ✕
            </button>
          </div>

          <div className="mt-3 space-y-2 text-xs">
            <div className="flex justify-between py-1 border-b border-slate-800/80">
              <span className="text-slate-400">GUID</span>
              <span className="font-mono text-slate-200">{selectedElement.guid}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-800/80">
              <span className="text-slate-400">Grid Location</span>
              <span className="text-slate-200">{selectedElement.grid}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-800/80">
              <span className="text-slate-400">Material</span>
              <span className="text-slate-200 truncate max-w-[170px]">{selectedElement.material}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-800/80">
              <span className="text-slate-400">Field Status</span>
              <span className="font-medium text-emerald-400">{selectedElement.fabricationStatus}</span>
            </div>
          </div>

          {/* Clash Notice in Inspector */}
          {selectedElement.hasClash && (
            <div className="mt-3 p-2.5 bg-red-950/50 border border-red-800/60 rounded text-xs text-red-200">
              <div className="flex items-center gap-1 font-semibold text-red-300">
                <AlertTriangle className="w-3.5 h-3.5 text-red-400" />
                <span>BIM Collision Detected</span>
              </div>
              <p className="mt-1 text-slate-300 leading-relaxed">
                {selectedElement.clashDescription}
              </p>
            </div>
          )}

          {/* Linked RFI or Action */}
          <div className="mt-3 pt-2 border-t border-slate-800 flex items-center justify-between">
            {selectedElement.linkedRfiId && selectedElementRfi ? (
              <button
                onClick={() => onOpenRfi && onOpenRfi(selectedElement.linkedRfiId!)}
                className="w-full flex items-center justify-center gap-1.5 px-3 py-1.5 bg-amber-500/20 text-amber-300 border border-amber-500/40 rounded hover:bg-amber-500/30 text-xs font-medium transition-colors"
              >
                <FileQuestion className="w-3.5 h-3.5" />
                <span>View {selectedElementRfi.number} ({selectedElementRfi.status})</span>
              </button>
            ) : (
              <button
                onClick={() => onOpenRfi && onOpenRfi('new-for-' + selectedElement.id)}
                className="w-full flex items-center justify-center gap-1.5 px-3 py-1.5 bg-slate-800 text-slate-200 border border-slate-700 rounded hover:bg-slate-700 text-xs font-medium transition-colors"
              >
                <span>+ Create RFI on Element</span>
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
