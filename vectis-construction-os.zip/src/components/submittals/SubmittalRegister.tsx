import React, { useState } from 'react';
import { SubmittalItem, SubmittalStatus } from '../../types';
import { 
  FileCheck2, 
  Search, 
  Plus, 
  CheckCircle, 
  AlertTriangle, 
  Clock, 
  Layers, 
  FileText,
  Calendar,
  Stamp,
  Download
} from 'lucide-react';

interface SubmittalRegisterProps {
  submittals: SubmittalItem[];
  onAddSubmittal: (newSub: SubmittalItem) => void;
  onUpdateSubmittal: (updatedSub: SubmittalItem) => void;
  onNavigateToBim?: (guid?: string) => void;
}

export const SubmittalRegister: React.FC<SubmittalRegisterProps> = ({
  submittals,
  onAddSubmittal,
  onUpdateSubmittal,
  onNavigateToBim,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [divisionFilter, setDivisionFilter] = useState<string>('All');
  const [selectedSubmittal, setSelectedSubmittal] = useState<SubmittalItem | null>(null);
  const [isCreatingSubmittal, setIsCreatingSubmittal] = useState(false);

  // Stamp state in review drawer
  const [stampDecision, setStampDecision] = useState<SubmittalStatus>('Approved as Noted');
  const [stampNotes, setStampNotes] = useState('');
  const [reviewerName, setReviewerName] = useState('Elena Rostova, AIA (Lead Architect)');

  // New submittal form
  const [newTitle, setNewTitle] = useState('');
  const [newSpecDivision, setNewSpecDivision] = useState('05 - Metals');
  const [newType, setNewType] = useState<SubmittalItem['type']>('Shop Drawings');
  const [newLeadTime, setNewLeadTime] = useState(6);
  const [newRequiredDate, setNewRequiredDate] = useState('2026-10-30');
  const [newFabricator, setNewFabricator] = useState('Apex Structural Fab Inc.');
  const [newReviewer, setNewReviewer] = useState('Marcus Vance, PE (Arup)');

  const filteredSubmittals = submittals.filter((item) => {
    const matchesSearch =
      item.number.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.fabricator.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'All' || item.status === statusFilter;
    const matchesDivision = divisionFilter === 'All' || item.specDivision.startsWith(divisionFilter);
    return matchesSearch && matchesStatus && matchesDivision;
  });

  const handleSubmitNew = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const divCode = newSpecDivision.slice(0, 2);
    const itemNum = `SUB-${divCode}.${submittals.length + 10}`;

    const newSub: SubmittalItem = {
      id: `sub-${Date.now()}`,
      number: itemNum,
      specDivision: newSpecDivision,
      title: newTitle,
      type: newType,
      revision: 0,
      status: 'Submitted',
      leadTimeWeeks: Number(newLeadTime),
      requiredOnSiteDate: newRequiredDate,
      fabricator: newFabricator,
      reviewer: newReviewer,
      ballInCourt: newReviewer,
      dateSubmitted: new Date().toISOString().split('T')[0],
    };

    onAddSubmittal(newSub);
    setIsCreatingSubmittal(false);
    setSelectedSubmittal(newSub);
    setNewTitle('');
  };

  const handleApplyReviewStamp = () => {
    if (!selectedSubmittal) return;
    const updated: SubmittalItem = {
      ...selectedSubmittal,
      status: stampDecision,
      stampNote: stampNotes,
      reviewer: reviewerName,
      dateApproved: new Date().toISOString().split('T')[0],
      ballInCourt: stampDecision === 'Revise & Resubmit' ? 'Subcontractor / Fabricator' : 'General Contractor (Record)',
    };
    onUpdateSubmittal(updated);
    setSelectedSubmittal(updated);
    setStampNotes('');
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <span>Project Management</span>
            <span aria-hidden="true">·</span>
            <span>Submittal Register</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono text-slate-300">{filteredSubmittals.length} Items</span>
          </div>
          <h2 className="text-xl font-bold text-slate-100 mt-1">Shop Drawings & Submittals</h2>
        </div>

        <button
          onClick={() => setIsCreatingSubmittal(true)}
          className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-900 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors whitespace-nowrap shadow-sm self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>New Submittal Package</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-3 bg-slate-900/60 border border-slate-800/80 rounded-lg">
        <div className="relative flex-1 min-w-[240px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search submittal title, spec, or fabricator..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-950 border border-slate-800 rounded-md text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-500/60"
          />
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {/* Status Tabs */}
          <div className="flex items-center gap-1 p-0.5 bg-slate-950 border border-slate-800 rounded-md">
            {['All', 'Approved', 'Approved as Noted', 'Revise & Resubmit', 'In Review'].map((status) => (
              <button
                key={status}
                onClick={() => setStatusFilter(status)}
                className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap ${
                  statusFilter === status
                    ? 'bg-slate-800 text-slate-100 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {status}
              </button>
            ))}
          </div>

          {/* CSI Division Filter */}
          <select
            value={divisionFilter}
            onChange={(e) => setDivisionFilter(e.target.value)}
            className="px-2.5 py-1.5 text-xs bg-slate-950 border border-slate-800 rounded-md text-slate-300 focus:outline-none cursor-pointer"
          >
            <option value="All">All CSI Divisions</option>
            <option value="03">Div 03 - Concrete</option>
            <option value="05">Div 05 - Metals</option>
            <option value="13">Div 13 - Modular Units</option>
            <option value="23">Div 23 - HVAC Ducts</option>
            <option value="26">Div 26 - Electrical</option>
          </select>
        </div>
      </div>

      {/* Submittal Data Grid */}
      <div className="border border-slate-800/80 rounded-lg bg-slate-900/40 overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-900/90 text-slate-400 border-b border-slate-800 uppercase font-mono tracking-wider text-[11px]">
              <tr>
                <th className="py-2.5 px-4 font-medium">Submittal #</th>
                <th className="py-2.5 px-4 font-medium">Title & Specification</th>
                <th className="py-2.5 px-3 font-medium">Type</th>
                <th className="py-2.5 px-3 font-medium">Rev</th>
                <th className="py-2.5 px-3 font-medium">Review Status</th>
                <th className="py-2.5 px-3 font-medium">Lead Time</th>
                <th className="py-2.5 px-3 font-medium">Required On Site</th>
                <th className="py-2.5 px-3 font-medium text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {filteredSubmittals.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-500">
                    No submittals found matching criteria.
                  </td>
                </tr>
              ) : (
                filteredSubmittals.map((sub) => (
                  <tr
                    key={sub.id}
                    onClick={() => setSelectedSubmittal(sub)}
                    className="hover:bg-slate-800/40 transition-colors cursor-pointer group"
                  >
                    <td className="py-3 px-4 font-mono font-semibold text-slate-200 whitespace-nowrap">
                      {sub.number}
                    </td>
                    <td className="py-3 px-4 max-w-sm">
                      <div className="font-medium text-slate-100 group-hover:text-amber-300 transition-colors truncate">
                        {sub.title}
                      </div>
                      <div className="text-[11px] text-slate-400 truncate mt-0.5">
                        {sub.specDivision} · Fab: {sub.fabricator}
                      </div>
                    </td>
                    <td className="py-3 px-3 text-slate-300 whitespace-nowrap">
                      {sub.type}
                    </td>
                    <td className="py-3 px-3 font-mono text-slate-400 whitespace-nowrap">
                      Rev {sub.revision}
                    </td>
                    <td className="py-3 px-3 whitespace-nowrap">
                      <span className={`text-xs font-medium ${
                        sub.status === 'Approved' ? 'text-emerald-400' :
                        sub.status === 'Approved as Noted' ? 'text-teal-400' :
                        sub.status === 'Revise & Resubmit' ? 'text-red-400' :
                        sub.status === 'In Review' ? 'text-sky-400' : 'text-slate-400'
                      }`}>
                        {sub.status}
                      </span>
                    </td>
                    <td className="py-3 px-3 font-mono tabular-nums text-slate-300 whitespace-nowrap">
                      {sub.leadTimeWeeks} weeks
                    </td>
                    <td className="py-3 px-3 font-mono text-slate-300 whitespace-nowrap">
                      {sub.requiredOnSiteDate}
                    </td>
                    <td className="py-3 px-3 text-right whitespace-nowrap">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedSubmittal(sub);
                        }}
                        className="px-2 py-1 text-slate-300 hover:text-white hover:bg-slate-800 rounded border border-slate-700/60 text-[11px]"
                      >
                        Review Stamp
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Submittal Review & Approval Stamp Modal */}
      {selectedSubmittal && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-xl shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col overflow-hidden">
            <div className="p-4 border-b border-slate-800 flex items-start justify-between bg-slate-950">
              <div>
                <div className="flex items-center gap-2 text-xs text-slate-400 font-mono">
                  <span className="text-amber-400 font-bold">{selectedSubmittal.number}</span>
                  <span>·</span>
                  <span>Revision {selectedSubmittal.revision}</span>
                  <span>·</span>
                  <span>Submitted {selectedSubmittal.dateSubmitted}</span>
                </div>
                <h3 className="text-base font-semibold text-slate-100 mt-1">
                  {selectedSubmittal.title}
                </h3>
              </div>
              <button
                onClick={() => setSelectedSubmittal(null)}
                className="text-slate-400 hover:text-slate-100 p-1"
              >
                ✕
              </button>
            </div>

            <div className="p-5 overflow-y-auto space-y-4 text-xs text-slate-300">
              {/* Properties */}
              <div className="grid grid-cols-2 gap-3 p-3 bg-slate-950/70 border border-slate-800 rounded-lg">
                <div>
                  <span className="text-slate-500">CSI MasterFormat:</span>
                  <div className="text-slate-200 font-medium mt-0.5">{selectedSubmittal.specDivision}</div>
                </div>
                <div>
                  <span className="text-slate-500">Fabricator / Vendor:</span>
                  <div className="text-slate-200 font-medium mt-0.5">{selectedSubmittal.fabricator}</div>
                </div>
                <div>
                  <span className="text-slate-500">Procurement Lead Time:</span>
                  <div className="font-mono text-slate-200 mt-0.5">{selectedSubmittal.leadTimeWeeks} Weeks</div>
                </div>
                <div>
                  <span className="text-slate-500">Required On-Site Date:</span>
                  <div className="font-mono text-slate-200 mt-0.5">{selectedSubmittal.requiredOnSiteDate}</div>
                </div>
              </div>

              {/* Existing Stamp */}
              {selectedSubmittal.stampNote && (
                <div className="p-3.5 bg-slate-950 border border-slate-800 rounded-lg relative overflow-hidden">
                  <div className="flex items-center justify-between pb-2 border-b border-slate-800/80">
                    <span className="font-bold uppercase tracking-wider text-xs text-emerald-400 flex items-center gap-1.5">
                      <Stamp className="w-3.5 h-3.5" />
                      <span>{selectedSubmittal.status}</span>
                    </span>
                    <span className="text-slate-400 font-mono text-[11px]">{selectedSubmittal.dateApproved}</span>
                  </div>
                  <p className="mt-2 text-slate-200 leading-relaxed font-sans">{selectedSubmittal.stampNote}</p>
                  <div className="mt-2 text-[11px] text-slate-400">
                    Reviewer: <strong className="text-slate-200">{selectedSubmittal.reviewer}</strong>
                  </div>
                </div>
              )}

              {/* Architectural / Engineering Review Action */}
              <div className="p-4 bg-slate-950/80 border border-slate-800 rounded-lg space-y-3">
                <div className="text-xs font-semibold text-slate-200">
                  Architect / Engineer Action Stamp
                </div>
                
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {(['Approved', 'Approved as Noted', 'Revise & Resubmit', 'Rejected'] as SubmittalStatus[]).map((action) => (
                    <button
                      key={action}
                      type="button"
                      onClick={() => setStampDecision(action)}
                      className={`p-2 rounded text-xs font-semibold border text-center transition-colors ${
                        stampDecision === action
                          ? action === 'Approved'
                            ? 'bg-emerald-950 text-emerald-300 border-emerald-600'
                            : action === 'Approved as Noted'
                            ? 'bg-teal-950 text-teal-300 border-teal-600'
                            : action === 'Revise & Resubmit'
                            ? 'bg-amber-950 text-amber-300 border-amber-600'
                            : 'bg-red-950 text-red-300 border-red-600'
                          : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
                      }`}
                    >
                      {action}
                    </button>
                  ))}
                </div>

                <div>
                  <label className="block text-slate-400 mb-1">Review Stamp Notation / Revisions Required</label>
                  <textarea
                    rows={3}
                    placeholder="Provide specific notes regarding compliance with contract documents, torque test requirements, finish samples..."
                    value={stampNotes}
                    onChange={(e) => setStampNotes(e.target.value)}
                    className="w-full p-2.5 text-xs bg-slate-900 border border-slate-800 rounded text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div className="flex items-center justify-between pt-1">
                  <input
                    type="text"
                    value={reviewerName}
                    onChange={(e) => setReviewerName(e.target.value)}
                    className="px-2 py-1 text-xs bg-slate-900 border border-slate-800 rounded text-slate-300 w-64"
                  />
                  <button
                    onClick={handleApplyReviewStamp}
                    className="px-3.5 py-1.5 text-xs font-semibold text-slate-900 bg-amber-400 hover:bg-amber-300 rounded transition-colors"
                  >
                    Stamp & Release Submittal
                  </button>
                </div>
              </div>
            </div>

            <div className="p-3 border-t border-slate-800 bg-slate-950 flex items-center justify-end">
              <button
                onClick={() => setSelectedSubmittal(null)}
                className="px-3 py-1.5 text-xs text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* New Submittal Modal */}
      {isCreatingSubmittal && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-xl shadow-2xl w-full max-w-lg max-h-[90vh] flex flex-col overflow-hidden">
            <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950">
              <h3 className="text-base font-bold text-slate-100">Create Submittal Package</h3>
              <button
                onClick={() => setIsCreatingSubmittal(false)}
                className="text-slate-400 hover:text-slate-100 p-1"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmitNew} className="p-5 overflow-y-auto space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Submittal Title *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Structural steel moment connections & shop weld procedures"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full p-2 text-xs bg-slate-950 border border-slate-800 rounded-md text-slate-200 focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">CSI Spec Division</label>
                  <select
                    value={newSpecDivision}
                    onChange={(e) => setNewSpecDivision(e.target.value)}
                    className="w-full p-2 text-xs bg-slate-950 border border-slate-800 rounded-md text-slate-200 focus:outline-none focus:border-amber-500 cursor-pointer"
                  >
                    <option value="03 - Concrete">03 - Concrete</option>
                    <option value="05 - Metals">05 - Metals</option>
                    <option value="08 - Openings">08 - Openings & Glazing</option>
                    <option value="13 - Modular Units">13 - Modular Assemblies</option>
                    <option value="23 - HVAC Ducts">23 - HVAC Ducts</option>
                    <option value="26 - Electrical">26 - Electrical</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Submittal Type</label>
                  <select
                    value={newType}
                    onChange={(e) => setNewType(e.target.value as any)}
                    className="w-full p-2 text-xs bg-slate-950 border border-slate-800 rounded-md text-slate-200 focus:outline-none focus:border-amber-500 cursor-pointer"
                  >
                    <option value="Shop Drawings">Shop Drawings</option>
                    <option value="Product Data">Product Data</option>
                    <option value="Material Sample">Material Sample</option>
                    <option value="Test Report">Test Report</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Lead Time (Weeks)</label>
                  <input
                    type="number"
                    value={newLeadTime}
                    onChange={(e) => setNewLeadTime(Number(e.target.value))}
                    className="w-full p-2 text-xs bg-slate-950 border border-slate-800 rounded-md text-slate-200 focus:outline-none focus:border-amber-500 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Required On-Site Date</label>
                  <input
                    type="date"
                    value={newRequiredDate}
                    onChange={(e) => setNewRequiredDate(e.target.value)}
                    className="w-full p-2 text-xs bg-slate-950 border border-slate-800 rounded-md text-slate-200 focus:outline-none focus:border-amber-500 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Fabricator / Vendor</label>
                  <input
                    type="text"
                    value={newFabricator}
                    onChange={(e) => setNewFabricator(e.target.value)}
                    className="w-full p-2 text-xs bg-slate-950 border border-slate-800 rounded-md text-slate-200 focus:outline-none focus:border-amber-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Reviewing Consultant</label>
                  <input
                    type="text"
                    value={newReviewer}
                    onChange={(e) => setNewReviewer(e.target.value)}
                    className="w-full p-2 text-xs bg-slate-950 border border-slate-800 rounded-md text-slate-200 focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsCreatingSubmittal(false)}
                  className="px-3 py-1.5 text-xs text-slate-400 hover:text-slate-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-semibold text-slate-900 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors"
                >
                  Submit for Review
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
