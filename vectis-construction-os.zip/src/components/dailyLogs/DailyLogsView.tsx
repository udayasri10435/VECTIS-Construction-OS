import React, { useState } from 'react';
import { DailyLog, TradeCrewLog, EquipmentLog, DeliveryLog } from '../../types';
import { 
  Calendar, 
  Sun, 
  CloudRain, 
  Wind, 
  Users, 
  Truck, 
  Wrench, 
  ShieldCheck, 
  Camera, 
  FileCheck, 
  Plus, 
  Printer, 
  Clock,
  CheckCircle,
  AlertTriangle
} from 'lucide-react';

interface DailyLogsViewProps {
  logs: DailyLog[];
  onAddLog: (newLog: DailyLog) => void;
  onUpdateLog: (updatedLog: DailyLog) => void;
}

export const DailyLogsView: React.FC<DailyLogsViewProps> = ({
  logs,
  onAddLog,
  onUpdateLog,
}) => {
  const [selectedLogId, setSelectedLogId] = useState<string>(logs[0]?.id || '');
  const activeLog = logs.find((l) => l.id === selectedLogId) || logs[0];

  // Quick crew addition in active log
  const [showAddCrew, setShowAddCrew] = useState(false);
  const [newTrade, setNewTrade] = useState('');
  const [newSubcontractor, setNewSubcontractor] = useState('');
  const [newWorkers, setNewWorkers] = useState(6);
  const [newHours, setNewHours] = useState(48);
  const [newDescription, setNewDescription] = useState('');
  const [newLocation, setNewLocation] = useState('Level 2 Central');

  // Quick delivery addition
  const [showAddDelivery, setShowAddDelivery] = useState(false);
  const [newMaterial, setNewMaterial] = useState('');
  const [newSupplier, setNewSupplier] = useState('');
  const [newQty, setNewQty] = useState('');

  // Total craft hours calculation
  const totalCraftHours = activeLog?.laborCrews.reduce((acc, c) => acc + c.hoursWorked, 0) || 0;
  const totalCraftWorkers = activeLog?.laborCrews.reduce((acc, c) => acc + c.workersCount, 0) || 0;

  const handleSignDailyLog = () => {
    if (!activeLog) return;
    const updated: DailyLog = {
      ...activeLog,
      signedBySuperintendent: true,
      signedAt: `${new Date().toISOString().split('T')[0]} ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} CST`,
    };
    onUpdateLog(updated);
  };

  const handleAddCrew = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeLog || !newTrade.trim()) return;

    const crewItem: TradeCrewLog = {
      id: `crew-${Date.now()}`,
      trade: newTrade,
      subcontractor: newSubcontractor || 'Self-Perform / GC',
      workersCount: Number(newWorkers),
      hoursWorked: Number(newHours),
      workDescription: newDescription || 'Standard shift production.',
      locationArea: newLocation,
    };

    const updated: DailyLog = {
      ...activeLog,
      laborCrews: [...activeLog.laborCrews, crewItem],
    };
    onUpdateLog(updated);
    setShowAddCrew(false);
    setNewTrade('');
    setNewDescription('');
  };

  const handleAddDelivery = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeLog || !newMaterial.trim()) return;

    const delItem: DeliveryLog = {
      id: `del-${Date.now()}`,
      material: newMaterial,
      supplier: newSupplier,
      quantity: newQty,
      deliveryTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      qaPassed: true,
      stagingBay: 'Bay B - Unloading Zone',
    };

    const updated: DailyLog = {
      ...activeLog,
      deliveries: [...activeLog.deliveries, delItem],
    };
    onUpdateLog(updated);
    setShowAddDelivery(false);
    setNewMaterial('');
    setNewQty('');
  };

  if (!activeLog) {
    return <div className="p-8 text-center text-slate-500">No daily logs recorded yet.</div>;
  }

  return (
    <div className="space-y-4">
      {/* Header and Date Selector */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <span>Field Operations</span>
            <span aria-hidden="true">·</span>
            <span>Daily Logs</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono text-slate-300">Superintendent: {activeLog.superintendent}</span>
          </div>
          <h2 className="text-xl font-bold text-slate-100 mt-1">Superintendent Field Log</h2>
        </div>

        <div className="flex items-center gap-2">
          {/* Date Selector Tabs */}
          <div className="flex items-center gap-1 p-0.5 bg-slate-900 border border-slate-800 rounded-lg">
            {logs.map((log) => (
              <button
                key={log.id}
                onClick={() => setSelectedLogId(log.id)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap font-mono ${
                  activeLog.id === log.id
                    ? 'bg-amber-400 text-slate-950 font-semibold shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {log.date}
              </button>
            ))}
          </div>

          <button
            onClick={() => window.print()}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-lg transition-colors"
            title="Print Official Daily Report"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Report</span>
          </button>
        </div>
      </div>

      {/* Weather & Site Conditions Bar */}
      <div className="p-4 bg-slate-900/70 border border-slate-800 rounded-lg grid grid-cols-2 md:grid-cols-5 gap-3 text-xs">
        <div className="flex items-center gap-2.5">
          <div className="p-2 bg-amber-500/10 text-amber-400 rounded-md">
            <Sun className="w-4 h-4" />
          </div>
          <div>
            <div className="text-slate-400 text-[11px]">Conditions</div>
            <div className="font-semibold text-slate-100">{activeLog.weather.condition}</div>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          <div className="p-2 bg-sky-500/10 text-sky-400 rounded-md">
            <Clock className="w-4 h-4" />
          </div>
          <div>
            <div className="text-slate-400 text-[11px]">Temperature Range</div>
            <div className="font-mono text-slate-100 font-semibold">
              {activeLog.weather.tempLow}°F - {activeLog.weather.tempHigh}°F
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          <div className="p-2 bg-slate-800 text-slate-300 rounded-md">
            <Wind className="w-4 h-4" />
          </div>
          <div>
            <div className="text-slate-400 text-[11px]">Wind & Crane Limit</div>
            <div className="font-mono text-slate-100 font-semibold">{activeLog.weather.windMph} MPH (Max 25)</div>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          <div className="p-2 bg-emerald-500/10 text-emerald-400 rounded-md">
            <CheckCircle className="w-4 h-4" />
          </div>
          <div>
            <div className="text-slate-400 text-[11px]">Ground Conditions</div>
            <div className="text-slate-100 font-semibold">{activeLog.weather.groundConditions}</div>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          <div className="p-2 bg-slate-800 text-slate-300 rounded-md">
            <Users className="w-4 h-4" />
          </div>
          <div>
            <div className="text-slate-400 text-[11px]">Total Headcount</div>
            <div className="font-mono text-slate-100 font-semibold">
              {totalCraftWorkers} Crafts ({totalCraftHours} hrs)
            </div>
          </div>
        </div>
      </div>

      {/* General Production Notes */}
      <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-lg">
        <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider font-mono">
          Superintendent Work Summary
        </h4>
        <p className="mt-2 text-xs text-slate-200 leading-relaxed font-sans">
          {activeLog.generalNotes}
        </p>
      </div>

      {/* 2-Column Operational Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Left: Trade Labor Crews */}
        <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-lg space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-amber-400" />
              <h4 className="text-xs font-semibold text-slate-200">Trade Crew Headcount & Hours</h4>
            </div>
            {!activeLog.signedBySuperintendent && (
              <button
                onClick={() => setShowAddCrew(true)}
                className="flex items-center gap-1 text-[11px] text-amber-400 hover:text-amber-300 font-medium"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Crew</span>
              </button>
            )}
          </div>

          <div className="space-y-2 text-xs">
            {activeLog.laborCrews.map((crew) => (
              <div key={crew.id} className="p-3 bg-slate-950/80 border border-slate-800/80 rounded-md">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-slate-100">{crew.trade}</span>
                  <span className="font-mono text-slate-300 tabular-nums">
                    {crew.workersCount} craft · {crew.hoursWorked} man-hrs
                  </span>
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5">
                  Sub: {crew.subcontractor} · Area: {crew.locationArea}
                </div>
                <div className="text-[11px] text-slate-300 mt-1 leading-snug">
                  {crew.workDescription}
                </div>
              </div>
            ))}
          </div>

          {/* Add Crew Inline Form */}
          {showAddCrew && (
            <form onSubmit={handleAddCrew} className="p-3 bg-slate-950 border border-amber-500/40 rounded-md space-y-2 text-xs">
              <div className="font-semibold text-amber-400 text-xs">Log Trade Crew</div>
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="text"
                  required
                  placeholder="Trade (e.g. Electricians)"
                  value={newTrade}
                  onChange={(e) => setNewTrade(e.target.value)}
                  className="p-1.5 bg-slate-900 border border-slate-700 rounded text-slate-200 text-xs"
                />
                <input
                  type="text"
                  placeholder="Company Name"
                  value={newSubcontractor}
                  onChange={(e) => setNewSubcontractor(e.target.value)}
                  className="p-1.5 bg-slate-900 border border-slate-700 rounded text-slate-200 text-xs"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="number"
                  placeholder="Workers Count"
                  value={newWorkers}
                  onChange={(e) => setNewWorkers(Number(e.target.value))}
                  className="p-1.5 bg-slate-900 border border-slate-700 rounded text-slate-200 text-xs font-mono"
                />
                <input
                  type="number"
                  placeholder="Total Hours"
                  value={newHours}
                  onChange={(e) => setNewHours(Number(e.target.value))}
                  className="p-1.5 bg-slate-900 border border-slate-700 rounded text-slate-200 text-xs font-mono"
                />
              </div>
              <input
                type="text"
                placeholder="Scope of work performed today..."
                value={newDescription}
                onChange={(e) => setNewDescription(e.target.value)}
                className="w-full p-1.5 bg-slate-900 border border-slate-700 rounded text-slate-200 text-xs"
              />
              <div className="flex justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setShowAddCrew(false)}
                  className="px-2 py-1 text-slate-400 hover:text-slate-200 text-[11px]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-3 py-1 bg-amber-400 text-slate-900 rounded font-semibold text-[11px]"
                >
                  Save Crew
                </button>
              </div>
            </form>
          )}
        </div>

        {/* Right: Heavy Equipment & Site Deliveries */}
        <div className="space-y-4">
          {/* Equipment Status */}
          <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-lg space-y-3">
            <div className="flex items-center gap-2">
              <Wrench className="w-4 h-4 text-sky-400" />
              <h4 className="text-xs font-semibold text-slate-200">Heavy Equipment Utilization</h4>
            </div>

            <div className="space-y-2 text-xs">
              {activeLog.equipment.map((eq) => (
                <div key={eq.id} className="p-2.5 bg-slate-950/80 border border-slate-800/80 rounded-md flex items-center justify-between">
                  <div>
                    <span className="font-semibold text-slate-100">{eq.equipmentType}</span>
                    <div className="text-[11px] text-slate-400 font-mono">Tag: {eq.idTag}</div>
                  </div>
                  <div className="text-right">
                    <span className="font-mono text-slate-200 text-[11px]">
                      {eq.hoursActive}h Active · {eq.hoursIdle}h Idle
                    </span>
                    <div className={`text-[11px] font-medium ${eq.status === 'Operational' ? 'text-emerald-400' : 'text-slate-400'}`}>
                      {eq.status}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Deliveries */}
          <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-lg space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Truck className="w-4 h-4 text-emerald-400" />
                <h4 className="text-xs font-semibold text-slate-200">Materials Received & QA Passed</h4>
              </div>
              {!activeLog.signedBySuperintendent && (
                <button
                  onClick={() => setShowAddDelivery(true)}
                  className="flex items-center gap-1 text-[11px] text-amber-400 hover:text-amber-300 font-medium"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Log Delivery</span>
                </button>
              )}
            </div>

            <div className="space-y-2 text-xs">
              {activeLog.deliveries.map((del) => (
                <div key={del.id} className="p-2.5 bg-slate-950/80 border border-slate-800/80 rounded-md">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-slate-100">{del.material}</span>
                    <span className="font-mono text-slate-400 text-[11px]">{del.deliveryTime}</span>
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    {del.supplier} · {del.quantity} · Staged at: {del.stagingBay}
                  </div>
                </div>
              ))}
            </div>

            {/* Delivery Form */}
            {showAddDelivery && (
              <form onSubmit={handleAddDelivery} className="p-3 bg-slate-950 border border-amber-500/40 rounded-md space-y-2 text-xs">
                <div className="font-semibold text-amber-400 text-xs">Record Delivery</div>
                <input
                  type="text"
                  required
                  placeholder="Material description (e.g. 5,000 PSI concrete batch)"
                  value={newMaterial}
                  onChange={(e) => setNewMaterial(e.target.value)}
                  className="w-full p-1.5 bg-slate-900 border border-slate-700 rounded text-slate-200 text-xs"
                />
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="text"
                    placeholder="Supplier / Mill"
                    value={newSupplier}
                    onChange={(e) => setNewSupplier(e.target.value)}
                    className="p-1.5 bg-slate-900 border border-slate-700 rounded text-slate-200 text-xs"
                  />
                  <input
                    type="text"
                    placeholder="Quantity & units"
                    value={newQty}
                    onChange={(e) => setNewQty(e.target.value)}
                    className="p-1.5 bg-slate-900 border border-slate-700 rounded text-slate-200 text-xs"
                  />
                </div>
                <div className="flex justify-end gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => setShowAddDelivery(false)}
                    className="px-2 py-1 text-slate-400 hover:text-slate-200 text-[11px]"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-3 py-1 bg-amber-400 text-slate-900 rounded font-semibold text-[11px]"
                  >
                    Save Delivery
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      </div>

      {/* Safety & Progress Photos */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Safety */}
        <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-lg space-y-3">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <h4 className="text-xs font-semibold text-slate-200">Safety Compliance & Daily Toolbox Talk</h4>
          </div>

          <div className="p-3 bg-slate-950 border border-slate-800 rounded-md text-xs space-y-2">
            <div>
              <span className="text-slate-400 text-[11px]">Today's Tailgate Safety Topic:</span>
              <div className="text-slate-100 font-medium mt-0.5">{activeLog.safetyTalkTopic}</div>
            </div>
            <div className="flex items-center gap-3 pt-2 border-t border-slate-800/80">
              <span className="text-emerald-400 font-semibold flex items-center gap-1">
                <CheckCircle className="w-3.5 h-3.5" />
                <span>Zero Incidents Reported</span>
              </span>
              <span className="text-slate-400">·</span>
              <span className="text-slate-400">Near-misses: 0</span>
            </div>
            {activeLog.incidentNotes && (
              <p className="text-slate-400 text-[11px] pt-1">{activeLog.incidentNotes}</p>
            )}
          </div>
        </div>

        {/* Progress Photos Log */}
        <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-lg space-y-3">
          <div className="flex items-center gap-2">
            <Camera className="w-4 h-4 text-amber-400" />
            <h4 className="text-xs font-semibold text-slate-200">Verified Field Progress Photos ({activeLog.photos.length})</h4>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
            {activeLog.photos.map((photo) => (
              <div key={photo.id} className="p-2.5 bg-slate-950 border border-slate-800 rounded-md flex flex-col justify-between">
                <div>
                  <div className="text-amber-400 font-mono text-[10px] uppercase font-semibold">{photo.tag}</div>
                  <div className="text-slate-200 font-medium text-[11px] mt-0.5 line-clamp-1">{photo.title}</div>
                  <p className="text-slate-400 text-[10px] mt-1 line-clamp-2 leading-tight">{photo.caption}</p>
                </div>
                <div className="text-[10px] text-slate-500 font-mono mt-2 pt-1 border-t border-slate-800">
                  {photo.time} · Verified QA
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Superintendent Sign-Off Card */}
      <div className="p-4 bg-slate-900/90 border border-slate-800 rounded-lg flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="text-xs text-slate-400 font-medium">Daily Log Sign-Off & Legal Verification</div>
          <div className="text-sm font-semibold text-slate-200 mt-0.5">
            Superintendent: {activeLog.superintendent}
          </div>
          {activeLog.signedBySuperintendent ? (
            <div className="text-xs text-emerald-400 mt-1 flex items-center gap-1.5 font-mono">
              <CheckCircle className="w-3.5 h-3.5" />
              <span>Electronically signed & locked at {activeLog.signedAt}</span>
            </div>
          ) : (
            <div className="text-xs text-amber-400 mt-1">
              Log is currently open for end-of-shift updates.
            </div>
          )}
        </div>

        {!activeLog.signedBySuperintendent && (
          <button
            onClick={handleSignDailyLog}
            className="px-4 py-2 text-xs font-semibold text-slate-900 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors whitespace-nowrap shadow-sm"
          >
            Sign & Lock Daily Field Log
          </button>
        )}
      </div>
    </div>
  );
};
