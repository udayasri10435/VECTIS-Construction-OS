import React from 'react';
import { Project, RfiItem, SubmittalItem, ChangeOrderItem, DailyLog, BimElement } from '../../types';
import { 
  Building2, 
  FileQuestion, 
  FileCheck2, 
  DollarSign, 
  Calendar, 
  AlertTriangle, 
  TrendingUp, 
  Users, 
  Layers, 
  ArrowUpRight, 
  CheckCircle2, 
  Clock,
  ShieldCheck,
  HardHat
} from 'lucide-react';

interface ExecutiveDashboardProps {
  project: Project;
  rfis: RfiItem[];
  submittals: SubmittalItem[];
  changeOrders: ChangeOrderItem[];
  dailyLogs: DailyLog[];
  bimElements: BimElement[];
  onNavigateTab: (tab: 'overview' | 'bim' | 'rfis' | 'submittals' | 'changeOrders' | 'dailyLogs') => void;
  onOpenRfi: (rfiId: string) => void;
}

export const ExecutiveDashboard: React.FC<ExecutiveDashboardProps> = ({
  project,
  rfis,
  submittals,
  changeOrders,
  dailyLogs,
  bimElements,
  onNavigateTab,
  onOpenRfi,
}) => {
  const latestLog = dailyLogs[0];
  const openRfis = rfis.filter((r) => r.status === 'Open' || r.status === 'Under Review');
  const criticalRfis = rfis.filter((r) => r.priority === 'Critical');
  const pendingSubmittals = submittals.filter((s) => s.status === 'In Review' || s.status === 'Submitted');
  const clashingElements = bimElements.filter((b) => b.hasClash);

  const approvedCoTotal = changeOrders
    .filter((c) => c.status === 'Approved')
    .reduce((acc, c) => acc + c.totalAmount, 0);

  const pendingCoTotal = changeOrders
    .filter((c) => c.status === 'Pending Review')
    .reduce((acc, c) => acc + c.totalAmount, 0);

  const totalCraftWorkers = latestLog?.laborCrews.reduce((sum, c) => sum + c.workersCount, 0) || 0;
  const totalCraftHours = latestLog?.laborCrews.reduce((sum, c) => sum + c.hoursWorked, 0) || 0;

  return (
    <div className="space-y-5">
      {/* Top Banner: Project Status & Weather */}
      <div className="p-5 bg-gradient-to-r from-slate-900 via-slate-900 to-slate-950 border border-slate-800 rounded-xl relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono text-amber-400">
              <span className="font-bold tracking-wider">{project.code}</span>
              <span className="text-slate-500">·</span>
              <span className="text-slate-300">{project.type}</span>
              <span className="text-slate-500">·</span>
              <span className="text-slate-400">{project.location}</span>
            </div>
            <h1 className="text-2xl font-bold text-slate-100 mt-1">
              {project.name}
            </h1>
            <p className="text-xs text-slate-400 mt-0.5">
              Client: <strong className="text-slate-200">{project.client}</strong> · Contract: ${(project.contractValue / 1000000).toFixed(1)}M
            </p>
          </div>

          {/* Quick Metrics Bar */}
          <div className="flex items-center gap-4 text-xs font-mono tabular-nums shrink-0">
            <div className="p-3 bg-slate-950/80 border border-slate-800 rounded-lg">
              <div className="text-[11px] text-slate-400">Completion</div>
              <div className="text-base font-bold text-amber-400">{project.completionPercent}%</div>
            </div>
            <div className="p-3 bg-slate-950/80 border border-slate-800 rounded-lg">
              <div className="text-[11px] text-slate-400">Field Weather</div>
              <div className="text-base font-bold text-slate-100">{project.weather.temp}°F · {project.weather.condition.split('/')[0]}</div>
            </div>
            <div className="p-3 bg-slate-950/80 border border-slate-800 rounded-lg">
              <div className="text-[11px] text-slate-400">Contingency</div>
              <div className="text-base font-bold text-emerald-400">${(project.contingencyRemaining / 1000000).toFixed(2)}M</div>
            </div>
          </div>
        </div>
      </div>

      {/* 4 Primary Pillar Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* RFI Pillar */}
        <div 
          onClick={() => onNavigateTab('rfis')}
          className="p-4 bg-slate-900/60 border border-slate-800 hover:border-amber-500/50 rounded-xl transition-all cursor-pointer group shadow-sm flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between">
              <div className="p-2 bg-amber-500/10 text-amber-400 rounded-lg">
                <FileQuestion className="w-5 h-5" />
              </div>
              <ArrowUpRight className="w-4 h-4 text-slate-500 group-hover:text-amber-400 transition-colors" />
            </div>
            <div className="text-xs text-slate-400 mt-3 font-medium">Open RFIs</div>
            <div className="text-2xl font-bold font-mono tabular-nums text-slate-100 mt-1">
              {openRfis.length}
            </div>
          </div>
          <div className="mt-3 pt-2 border-t border-slate-800/80 text-xs text-slate-400 flex items-center justify-between">
            <span className="text-red-400 font-medium">{criticalRfis.length} Critical Priority</span>
            <span>Avg 4.2d response</span>
          </div>
        </div>

        {/* Submittals Pillar */}
        <div 
          onClick={() => onNavigateTab('submittals')}
          className="p-4 bg-slate-900/60 border border-slate-800 hover:border-sky-500/50 rounded-xl transition-all cursor-pointer group shadow-sm flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between">
              <div className="p-2 bg-sky-500/10 text-sky-400 rounded-lg">
                <FileCheck2 className="w-5 h-5" />
              </div>
              <ArrowUpRight className="w-4 h-4 text-slate-500 group-hover:text-sky-400 transition-colors" />
            </div>
            <div className="text-xs text-slate-400 mt-3 font-medium">Pending Submittal Packages</div>
            <div className="text-2xl font-bold font-mono tabular-nums text-slate-100 mt-1">
              {pendingSubmittals.length}
            </div>
          </div>
          <div className="mt-3 pt-2 border-t border-slate-800/80 text-xs text-slate-400 flex items-center justify-between">
            <span className="text-emerald-400 font-medium">4 Approved this week</span>
            <span>85% on schedule</span>
          </div>
        </div>

        {/* Change Orders Pillar */}
        <div 
          onClick={() => onNavigateTab('changeOrders')}
          className="p-4 bg-slate-900/60 border border-slate-800 hover:border-emerald-500/50 rounded-xl transition-all cursor-pointer group shadow-sm flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between">
              <div className="p-2 bg-emerald-500/10 text-emerald-400 rounded-lg">
                <DollarSign className="w-5 h-5" />
              </div>
              <ArrowUpRight className="w-4 h-4 text-slate-500 group-hover:text-emerald-400 transition-colors" />
            </div>
            <div className="text-xs text-slate-400 mt-3 font-medium">Pending Change Orders (PCO)</div>
            <div className="text-2xl font-bold font-mono tabular-nums text-slate-100 mt-1">
              ${pendingCoTotal.toLocaleString()}
            </div>
          </div>
          <div className="mt-3 pt-2 border-t border-slate-800/80 text-xs text-slate-400 flex items-center justify-between">
            <span className="text-slate-300 font-medium font-mono tabular-nums">+${approvedCoTotal.toLocaleString()} Approved</span>
            <span>+6d delta</span>
          </div>
        </div>

        {/* 3D BIM Clash Radar */}
        <div 
          onClick={() => onNavigateTab('bim')}
          className="p-4 bg-slate-900/60 border border-slate-800 hover:border-red-500/50 rounded-xl transition-all cursor-pointer group shadow-sm flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between">
              <div className="p-2 bg-red-500/10 text-red-400 rounded-lg">
                <Layers className="w-5 h-5" />
              </div>
              <ArrowUpRight className="w-4 h-4 text-slate-500 group-hover:text-red-400 transition-colors" />
            </div>
            <div className="text-xs text-slate-400 mt-3 font-medium">BIM Coordination & Clashes</div>
            <div className="text-2xl font-bold font-mono tabular-nums text-red-400 mt-1">
              {clashingElements.length} Hard Clashes
            </div>
          </div>
          <div className="mt-3 pt-2 border-t border-slate-800/80 text-xs text-slate-400 flex items-center justify-between">
            <span className="text-amber-400 font-medium">LOD 400 Verified</span>
            <span>Launch 3D Model →</span>
          </div>
        </div>
      </div>

      {/* Operational Split View: Action Items & Daily Field Report */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Critical Path & Urgent RFIs */}
        <div className="p-5 bg-slate-900/60 border border-slate-800 rounded-xl space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              <h3 className="text-sm font-bold text-slate-100">Critical Path RFIs & Decisions</h3>
            </div>
            <button
              onClick={() => onNavigateTab('rfis')}
              className="text-xs text-amber-400 hover:text-amber-300 font-medium"
            >
              View All ({rfis.length}) →
            </button>
          </div>

          <div className="space-y-2.5">
            {rfis.slice(0, 3).map((rfi) => (
              <div
                key={rfi.id}
                onClick={() => onOpenRfi(rfi.id)}
                className="p-3 bg-slate-950/70 border border-slate-800 hover:border-slate-700 rounded-lg cursor-pointer transition-colors"
              >
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="text-amber-400 font-semibold">{rfi.number}</span>
                  <span className={`text-[11px] font-medium ${
                    rfi.priority === 'Critical' ? 'text-red-400' : 'text-amber-400'
                  }`}>
                    {rfi.priority} Priority
                  </span>
                </div>
                <div className="text-xs font-semibold text-slate-200 mt-1 truncate">
                  {rfi.title}
                </div>
                <div className="flex items-center justify-between text-[11px] text-slate-400 mt-2 pt-2 border-t border-slate-800/60 font-mono">
                  <span>Due: {rfi.dateDue}</span>
                  <span>Ball: {rfi.ballInCourt}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Daily Superintendent Shift Summary */}
        <div className="p-5 bg-slate-900/60 border border-slate-800 rounded-xl space-y-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <HardHat className="w-4 h-4 text-sky-400" />
                <h3 className="text-sm font-bold text-slate-100">Today's Field Superintendent Report</h3>
              </div>
              <button
                onClick={() => onNavigateTab('dailyLogs')}
                className="text-xs text-sky-400 hover:text-sky-300 font-medium"
              >
                Full Daily Log →
              </button>
            </div>

            {latestLog && (
              <div className="mt-3 space-y-3 text-xs">
                <div className="p-3 bg-slate-950/70 border border-slate-800 rounded-lg">
                  <div className="flex items-center justify-between font-mono text-[11px] text-slate-400 pb-2 border-b border-slate-800">
                    <span>Date: <strong className="text-slate-200">{latestLog.date}</strong></span>
                    <span>Shift: {latestLog.shift}</span>
                  </div>
                  <p className="mt-2 text-slate-300 leading-relaxed font-sans line-clamp-2">
                    {latestLog.generalNotes}
                  </p>
                </div>

                <div className="grid grid-cols-3 gap-2 text-xs font-mono">
                  <div className="p-2.5 bg-slate-950/70 border border-slate-800 rounded-lg">
                    <span className="text-slate-400 text-[11px]">Craft Workers</span>
                    <div className="text-sm font-bold text-slate-100 mt-0.5">{totalCraftWorkers} Trades</div>
                  </div>
                  <div className="p-2.5 bg-slate-950/70 border border-slate-800 rounded-lg">
                    <span className="text-slate-400 text-[11px]">Man-Hours</span>
                    <div className="text-sm font-bold text-slate-100 mt-0.5">{totalCraftHours} hrs</div>
                  </div>
                  <div className="p-2.5 bg-slate-950/70 border border-slate-800 rounded-lg">
                    <span className="text-slate-400 text-[11px]">Safety Record</span>
                    <div className="text-sm font-bold text-emerald-400 mt-0.5">100% Zero-Loss</div>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs">
            <span className="text-slate-400">Superintendent: <strong className="text-slate-200">{latestLog?.superintendent}</strong></span>
            {latestLog?.signedBySuperintendent ? (
              <span className="text-emerald-400 font-mono flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Digitally Signed</span>
              </span>
            ) : (
              <span className="text-amber-400 font-mono">Pending End-of-Shift Sign</span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
