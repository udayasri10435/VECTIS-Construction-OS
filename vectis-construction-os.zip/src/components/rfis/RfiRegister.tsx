import React, { useState } from 'react';
import { RfiItem, BimElement } from '../../types';
import { 
  FileQuestion, 
  Search, 
  Plus, 
  AlertCircle, 
  Calendar, 
  Clock, 
  DollarSign, 
  User, 
  CheckCircle2, 
  ChevronRight,
  Download,
  Filter,
  Layers,
  ArrowUpRight
} from 'lucide-react';

interface RfiRegisterProps {
  rfis: RfiItem[];
  bimElements: BimElement[];
  onAddRfi: (newRfi: RfiItem) => void;
  onUpdateRfi: (updatedRfi: RfiItem) => void;
  onNavigateToBim?: (elementId?: string) => void;
  activeRfiId?: string | null;
  onSelectRfiId?: (id: string | null) => void;
}

export const RfiRegister: React.FC<RfiRegisterProps> = ({
  rfis,
  bimElements,
  onAddRfi,
  onUpdateRfi,
  onNavigateToBim,
  activeRfiId,
  onSelectRfiId,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [priorityFilter, setPriorityFilter] = useState<string>('All');
  const [selectedRfi, setSelectedRfi] = useState<RfiItem | null>(() => {
    if (activeRfiId) {
      return rfis.find(r => r.id === activeRfiId) || null;
    }
    return null;
  });
  const [isCreatingRfi, setIsCreatingRfi] = useState(false);

  // New RFI Form State
  const [newTitle, setNewTitle] = useState('');
  const [newSpec, setNewSpec] = useState('05 12 00 - Structural Steel');
  const [newDrawing, setNewDrawing] = useState('S-201 / Detail 4');
  const [newPriority, setNewPriority] = useState<RfiItem['priority']>('High');
  const [newQuestion, setNewQuestion] = useState('');
  const [newSolution, setNewSolution] = useState('');
  const [newAssignedTo, setNewAssignedTo] = useState('Marcus Vance, PE (Structural EOR)');
  const [newHasCost, setNewHasCost] = useState(false);
  const [newCostEstimate, setNewCostEstimate] = useState<number>(3500);
  const [newHasSchedule, setNewHasSchedule] = useState(false);
  const [newScheduleDays, setNewScheduleDays] = useState<number>(2);
  const [newLinkedBimId, setNewLinkedBimId] = useState<string>('');

  // Official Response Draft State in modal
  const [responseText, setResponseText] = useState('');
  const [responderName, setResponderName] = useState('Marcus Vance, PE');

  // Filtered RFIs
  const filteredRfis = rfis.filter((rfi) => {
    const matchesSearch =
      rfi.number.toLowerCase().includes(searchTerm.toLowerCase()) ||
      rfi.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      rfi.specSection.toLowerCase().includes(searchTerm.toLowerCase()) ||
      rfi.assignedTo.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'All' || rfi.status === statusFilter;
    const matchesPriority = priorityFilter === 'All' || rfi.priority === priorityFilter;
    return matchesSearch && matchesStatus && matchesPriority;
  });

  const handleOpenCreate = () => {
    setIsCreatingRfi(true);
  };

  const handleSubmitNewRfi = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newQuestion.trim()) return;

    const nextNumber = `RFI-0${rfis.length + 42}`;
    const newItem: RfiItem = {
      id: `rfi-${Date.now()}`,
      number: nextNumber,
      title: newTitle,
      specSection: newSpec,
      drawingReference: newDrawing,
      status: 'Open',
      priority: newPriority,
      assignedTo: newAssignedTo,
      assignedRole: 'Engineer of Record',
      ballInCourt: newAssignedTo,
      submittedBy: 'Field Superintendent',
      dateCreated: new Date().toISOString().split('T')[0],
      dateDue: new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0],
      question: newQuestion,
      suggestedSolution: newSolution,
      costImpact: newHasCost,
      costEstimate: newHasCost ? Number(newCostEstimate) : undefined,
      scheduleImpact: newHasSchedule,
      scheduleDays: newHasSchedule ? Number(newScheduleDays) : undefined,
      bimElementId: newLinkedBimId || undefined,
      gridReference: 'Grid B-4 / Level 2',
      attachmentsCount: 1,
    };

    onAddRfi(newItem);
    setIsCreatingRfi(false);
    setSelectedRfi(newItem);
    setNewTitle('');
    setNewQuestion('');
    setNewSolution('');
  };

  const handleEndorseResponse = () => {
    if (!selectedRfi || !responseText.trim()) return;
    const updated: RfiItem = {
      ...selectedRfi,
      status: 'Answered',
      officialResponse: responseText,
      respondedBy: responderName,
      responseDate: new Date().toISOString().split('T')[0],
      ballInCourt: 'General Contractor',
    };
    onUpdateRfi(updated);
    setSelectedRfi(updated);
    setResponseText('');
  };

  const handleCloseRfi = () => {
    if (!selectedRfi) return;
    const updated: RfiItem = {
      ...selectedRfi,
      status: 'Closed',
      dateClosed: new Date().toISOString().split('T')[0],
      ballInCourt: 'Closed / Archived',
    };
    onUpdateRfi(updated);
    setSelectedRfi(updated);
  };

  return (
    <div className="space-y-4">
      {/* Header and Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <span>Project Management</span>
            <span aria-hidden="true">·</span>
            <span>RFIs</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono text-slate-300">{filteredRfis.length} Records</span>
          </div>
          <h2 className="text-xl font-bold text-slate-100 mt-1">Requests for Information (RFIs)</h2>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleOpenCreate}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-900 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors whitespace-nowrap shadow-sm"
          >
            <Plus className="w-4 h-4" />
            <span>Create New RFI</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-3 bg-slate-900/60 border border-slate-800/80 rounded-lg">
        <div className="relative flex-1 min-w-[240px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search by RFI number, keyword, spec division, or engineer..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-950 border border-slate-800 rounded-md text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-500/60"
          />
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {/* Status Tabs */}
          <div className="flex items-center gap-1 p-0.5 bg-slate-950 border border-slate-800 rounded-md">
            {['All', 'Open', 'Under Review', 'Answered', 'Closed'].map((status) => (
              <button
                key={status}
                onClick={() => setStatusFilter(status)}
                className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap ${
                  statusFilter === status
                    ? 'bg-slate-800 text-slate-100 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {status}
              </button>
            ))}
          </div>

          {/* Priority Select */}
          <select
            value={priorityFilter}
            onChange={(e) => setPriorityFilter(e.target.value)}
            className="px-2.5 py-1.5 text-xs bg-slate-950 border border-slate-800 rounded-md text-slate-300 focus:outline-none cursor-pointer"
          >
            <option value="All">All Priorities</option>
            <option value="Critical">Critical</option>
            <option value="High">High</option>
            <option value="Medium">Medium</option>
            <option value="Low">Low</option>
          </select>
        </div>
      </div>

      {/* High-Density Data Grid */}
      <div className="border border-slate-800/80 rounded-lg bg-slate-900/40 overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-900/90 text-slate-400 border-b border-slate-800 uppercase font-mono tracking-wider text-[11px]">
              <tr>
                <th className="py-2.5 px-4 font-medium">Number</th>
                <th className="py-2.5 px-4 font-medium">Title & Spec</th>
                <th className="py-2.5 px-3 font-medium">Status</th>
                <th className="py-2.5 px-3 font-medium">Priority</th>
                <th className="py-2.5 px-3 font-medium">Ball in Court</th>
                <th className="py-2.5 px-3 font-medium">Impacts</th>
                <th className="py-2.5 px-3 font-medium">Date Due</th>
                <th className="py-2.5 px-3 font-medium text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {filteredRfis.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-500">
                    No RFIs match the active search or filters.
                  </td>
                </tr>
              ) : (
                filteredRfis.map((rfi) => (
                  <tr
                    key={rfi.id}
                    onClick={() => setSelectedRfi(rfi)}
                    className="hover:bg-slate-800/40 transition-colors cursor-pointer group"
                  >
                    <td className="py-3 px-4 font-mono font-semibold text-slate-200 whitespace-nowrap">
                      {rfi.number}
                    </td>
                    <td className="py-3 px-4 max-w-sm">
                      <div className="font-medium text-slate-100 group-hover:text-amber-300 transition-colors truncate">
                        {rfi.title}
                      </div>
                      <div className="text-[11px] text-slate-400 truncate mt-0.5">
                        {rfi.specSection} · {rfi.drawingReference}
                      </div>
                    </td>
                    <td className="py-3 px-3 whitespace-nowrap">
                      <span className={`inline-flex items-center text-xs font-medium ${
                        rfi.status === 'Open' ? 'text-amber-400' :
                        rfi.status === 'Under Review' ? 'text-sky-400' :
                        rfi.status === 'Answered' ? 'text-emerald-400' :
                        rfi.status === 'Closed' ? 'text-slate-400' : 'text-slate-300'
                      }`}>
                        {rfi.status}
                      </span>
                    </td>
                    <td className="py-3 px-3 whitespace-nowrap">
                      <span className={`text-xs font-medium ${
                        rfi.priority === 'Critical' ? 'text-red-400' :
                        rfi.priority === 'High' ? 'text-amber-400' :
                        rfi.priority === 'Medium' ? 'text-slate-300' : 'text-slate-500'
                      }`}>
                        {rfi.priority}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-slate-300 whitespace-nowrap truncate max-w-[160px]">
                      {rfi.ballInCourt}
                    </td>
                    <td className="py-3 px-3 whitespace-nowrap font-mono tabular-nums text-[11px]">
                      {rfi.costImpact || rfi.scheduleImpact ? (
                        <div className="space-y-0.5">
                          {rfi.costImpact && (
                            <div className="text-amber-400">
                              +${rfi.costEstimate?.toLocaleString()}
                            </div>
                          )}
                          {rfi.scheduleImpact && (
                            <div className="text-red-400">
                              +{rfi.scheduleDays}d schedule
                            </div>
                          )}
                        </div>
                      ) : (
                        <span className="text-slate-500">None</span>
                      )}
                    </td>
                    <td className="py-3 px-3 font-mono text-slate-400 whitespace-nowrap">
                      {rfi.dateDue}
                    </td>
                    <td className="py-3 px-3 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-1.5" onClick={(e) => e.stopPropagation()}>
                        {rfi.bimElementId && onNavigateToBim && (
                          <button
                            onClick={() => onNavigateToBim(rfi.bimElementId)}
                            className="p-1 text-sky-400 hover:bg-sky-950/60 rounded border border-sky-800/40 transition-colors"
                            title="View in 3D BIM Viewer"
                          >
                            <Layers className="w-3.5 h-3.5" />
                          </button>
                        )}
                        <button
                          onClick={() => setSelectedRfi(rfi)}
                          className="px-2 py-1 text-slate-300 hover:text-white hover:bg-slate-800 rounded border border-slate-700/60 text-[11px]"
                        >
                          Review
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* RFI Detail Drawer / Modal */}
      {selectedRfi && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-xl shadow-2xl w-full max-w-3xl max-h-[90vh] flex flex-col overflow-hidden">
            {/* Modal Header */}
            <div className="p-4 border-b border-slate-800 flex items-start justify-between bg-slate-950">
              <div>
                <div className="flex items-center gap-2 text-xs text-slate-400 font-mono">
                  <span className="text-amber-400 font-bold">{selectedRfi.number}</span>
                  <span>·</span>
                  <span>Created {selectedRfi.dateCreated}</span>
                  <span>·</span>
                  <span>Due {selectedRfi.dateDue}</span>
                </div>
                <h3 className="text-lg font-semibold text-slate-100 mt-1">
                  {selectedRfi.title}
                </h3>
              </div>
              <button
                onClick={() => setSelectedRfi(null)}
                className="text-slate-400 hover:text-slate-100 p-1.5 rounded-lg hover:bg-slate-800"
              >
                ✕
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-5 overflow-y-auto space-y-5 text-xs text-slate-300">
              {/* Metadata Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3 bg-slate-950/60 border border-slate-800/80 rounded-lg">
                <div>
                  <div className="text-slate-500 text-[11px]">Spec Section</div>
                  <div className="font-medium text-slate-200 mt-0.5">{selectedRfi.specSection}</div>
                </div>
                <div>
                  <div className="text-slate-500 text-[11px]">Drawing Ref</div>
                  <div className="font-medium text-slate-200 mt-0.5">{selectedRfi.drawingReference}</div>
                </div>
                <div>
                  <div className="text-slate-500 text-[11px]">Assigned Consultant</div>
                  <div className="font-medium text-slate-200 mt-0.5">{selectedRfi.assignedTo}</div>
                </div>
                <div>
                  <div className="text-slate-500 text-[11px]">Current Status</div>
                  <div className="font-medium text-amber-400 mt-0.5">{selectedRfi.status}</div>
                </div>
              </div>

              {/* Question Section */}
              <div className="space-y-1.5">
                <div className="text-slate-400 font-medium">Question / Field Issue:</div>
                <div className="p-3 bg-slate-950 border border-slate-800 rounded-md text-slate-200 leading-relaxed font-sans">
                  {selectedRfi.question}
                </div>
              </div>

              {/* Proposed Solution */}
              <div className="space-y-1.5">
                <div className="text-slate-400 font-medium">Contractor's Suggested Solution:</div>
                <div className="p-3 bg-slate-950 border border-slate-800 rounded-md text-slate-300 leading-relaxed">
                  {selectedRfi.suggestedSolution || 'None specified.'}
                </div>
              </div>

              {/* Cost & Schedule Impacts */}
              <div className="p-3 bg-slate-950/80 border border-slate-800 rounded-lg flex items-center justify-between">
                <div>
                  <div className="text-slate-400 font-medium">Cost & Schedule Exposure</div>
                  <div className="text-slate-500 text-[11px] mt-0.5">
                    Requires potential Change Order issuance if approved
                  </div>
                </div>
                <div className="flex items-center gap-4 font-mono tabular-nums">
                  <div>
                    <span className="text-slate-400 text-xs">Cost: </span>
                    <span className="text-slate-200 font-semibold">
                      {selectedRfi.costImpact ? `$${selectedRfi.costEstimate?.toLocaleString()}` : '$0.00'}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400 text-xs">Schedule: </span>
                    <span className="text-slate-200 font-semibold">
                      {selectedRfi.scheduleImpact ? `+${selectedRfi.scheduleDays} Days` : '0 Days'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Linked BIM Element */}
              {selectedRfi.bimElementId && (
                <div className="p-3 bg-sky-950/30 border border-sky-800/40 rounded-lg flex items-center justify-between">
                  <div>
                    <div className="text-sky-300 font-medium flex items-center gap-1.5">
                      <Layers className="w-3.5 h-3.5" />
                      <span>Linked 3D BIM Object</span>
                    </div>
                    <div className="text-slate-400 text-[11px] mt-0.5">
                      Element ID: <span className="font-mono text-slate-200">{selectedRfi.bimElementId}</span> ({selectedRfi.gridReference})
                    </div>
                  </div>
                  {onNavigateToBim && (
                    <button
                      onClick={() => {
                        setSelectedRfi(null);
                        onNavigateToBim(selectedRfi.bimElementId);
                      }}
                      className="px-2.5 py-1 text-xs font-medium text-sky-300 bg-sky-900/60 hover:bg-sky-800/80 border border-sky-700/60 rounded transition-colors"
                    >
                      Locate in 3D BIM
                    </button>
                  )}
                </div>
              )}

              {/* Official Response Section */}
              <div className="pt-2 border-t border-slate-800">
                <div className="text-slate-200 font-semibold mb-2">Architect / Engineer Official Response:</div>
                {selectedRfi.officialResponse ? (
                  <div className="p-3.5 bg-emerald-950/20 border border-emerald-800/50 rounded-lg space-y-2">
                    <p className="text-slate-200 leading-relaxed font-sans">{selectedRfi.officialResponse}</p>
                    <div className="flex items-center justify-between text-[11px] text-slate-400 pt-2 border-t border-emerald-900/40">
                      <span>Endorsed by: <strong className="text-slate-200">{selectedRfi.respondedBy}</strong></span>
                      <span className="font-mono">{selectedRfi.responseDate}</span>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <textarea
                      rows={3}
                      placeholder="Enter official architectural / engineering directive or response..."
                      value={responseText}
                      onChange={(e) => setResponseText(e.target.value)}
                      className="w-full p-2.5 text-xs bg-slate-950 border border-slate-800 rounded-md text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-500"
                    />
                    <div className="flex items-center justify-between">
                      <input
                        type="text"
                        placeholder="Responder Name & Credentials"
                        value={responderName}
                        onChange={(e) => setResponderName(e.target.value)}
                        className="px-2 py-1 text-xs bg-slate-950 border border-slate-800 rounded text-slate-300 w-64"
                      />
                      <button
                        onClick={handleEndorseResponse}
                        disabled={!responseText.trim()}
                        className="px-3 py-1.5 text-xs font-semibold text-slate-900 bg-emerald-400 hover:bg-emerald-300 disabled:opacity-50 rounded transition-colors"
                      >
                        Endorse Official Response
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-3 border-t border-slate-800 bg-slate-950 flex items-center justify-between">
              <button
                onClick={() => {
                  window.print();
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-slate-400 hover:text-slate-200 hover:bg-slate-900 rounded"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Print RFI Sheet</span>
              </button>

              <div className="flex items-center gap-2">
                {selectedRfi.status !== 'Closed' && (
                  <button
                    onClick={handleCloseRfi}
                    className="px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded transition-colors"
                  >
                    Close & Sign Off RFI
                  </button>
                )}
                <button
                  onClick={() => setSelectedRfi(null)}
                  className="px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 rounded"
                >
                  Done
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* New RFI Creation Modal */}
      {isCreatingRfi && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-xl shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col overflow-hidden">
            <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950">
              <h3 className="text-base font-bold text-slate-100">Draft Request for Information</h3>
              <button
                onClick={() => setIsCreatingRfi(false)}
                className="text-slate-400 hover:text-slate-100 p-1"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmitNewRfi} className="p-5 overflow-y-auto space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1">RFI Subject / Title *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Clearance discrepancy at elevator machine room header"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full p-2 text-xs bg-slate-950 border border-slate-800 rounded-md text-slate-200 focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">CSI Spec Section</label>
                  <input
                    type="text"
                    value={newSpec}
                    onChange={(e) => setNewSpec(e.target.value)}
                    className="w-full p-2 text-xs bg-slate-950 border border-slate-800 rounded-md text-slate-200 focus:outline-none focus:border-amber-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Drawing Sheet Reference</label>
                  <input
                    type="text"
                    value={newDrawing}
                    onChange={(e) => setNewDrawing(e.target.value)}
                    className="w-full p-2 text-xs bg-slate-950 border border-slate-800 rounded-md text-slate-200 focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Priority</label>
                  <select
                    value={newPriority}
                    onChange={(e) => setNewPriority(e.target.value as any)}
                    className="w-full p-2 text-xs bg-slate-950 border border-slate-800 rounded-md text-slate-200 focus:outline-none focus:border-amber-500 cursor-pointer"
                  >
                    <option value="Critical">Critical (Immediate Stop Work)</option>
                    <option value="High">High (Impacting 3-day lookahead)</option>
                    <option value="Medium">Medium (Normal review cycle)</option>
                    <option value="Low">Low (Informational / As-Built)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Assigned Consultant</label>
                  <input
                    type="text"
                    value={newAssignedTo}
                    onChange={(e) => setNewAssignedTo(e.target.value)}
                    className="w-full p-2 text-xs bg-slate-950 border border-slate-800 rounded-md text-slate-200 focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Question / Detailed Description *</label>
                <textarea
                  required
                  rows={3}
                  placeholder="Detail the field condition, discrepancy between architectural and structural drawings, or conflict..."
                  value={newQuestion}
                  onChange={(e) => setNewQuestion(e.target.value)}
                  className="w-full p-2 text-xs bg-slate-950 border border-slate-800 rounded-md text-slate-200 focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Contractor's Suggested Solution</label>
                <input
                  type="text"
                  placeholder="e.g. Provide slotted clips per detail S-502 or core 4-inch hole..."
                  value={newSolution}
                  onChange={(e) => setNewSolution(e.target.value)}
                  className="w-full p-2 text-xs bg-slate-950 border border-slate-800 rounded-md text-slate-200 focus:outline-none focus:border-amber-500"
                />
              </div>

              {/* Link BIM Element Option */}
              <div>
                <label className="block text-slate-300 font-medium mb-1">Link to 3D BIM Element (Optional)</label>
                <select
                  value={newLinkedBimId}
                  onChange={(e) => setNewLinkedBimId(e.target.value)}
                  className="w-full p-2 text-xs bg-slate-950 border border-slate-800 rounded-md text-slate-200 focus:outline-none focus:border-amber-500"
                >
                  <option value="">-- No 3D Element Selected --</option>
                  {bimElements.map((elem) => (
                    <option key={elem.id} value={elem.id}>
                      {elem.name} [{elem.guid}] - {elem.level} ({elem.grid})
                    </option>
                  ))}
                </select>
              </div>

              {/* Impacts */}
              <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg space-y-3">
                <div className="flex items-center justify-between">
                  <label className="flex items-center gap-2 text-slate-300 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newHasCost}
                      onChange={(e) => setNewHasCost(e.target.checked)}
                      className="rounded bg-slate-900 border-slate-700 text-amber-500 focus:ring-0"
                    />
                    <span>Anticipated Cost Impact</span>
                  </label>
                  {newHasCost && (
                    <div className="flex items-center gap-1">
                      <span className="text-slate-400">$</span>
                      <input
                        type="number"
                        value={newCostEstimate}
                        onChange={(e) => setNewCostEstimate(Number(e.target.value))}
                        className="w-24 p-1 text-xs bg-slate-900 border border-slate-700 rounded text-slate-200 font-mono"
                      />
                    </div>
                  )}
                </div>

                <div className="flex items-center justify-between">
                  <label className="flex items-center gap-2 text-slate-300 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newHasSchedule}
                      onChange={(e) => setNewHasSchedule(e.target.checked)}
                      className="rounded bg-slate-900 border-slate-700 text-amber-500 focus:ring-0"
                    />
                    <span>Anticipated Schedule Delay</span>
                  </label>
                  {newHasSchedule && (
                    <div className="flex items-center gap-1">
                      <input
                        type="number"
                        value={newScheduleDays}
                        onChange={(e) => setNewScheduleDays(Number(e.target.value))}
                        className="w-16 p-1 text-xs bg-slate-900 border border-slate-700 rounded text-slate-200 font-mono"
                      />
                      <span className="text-slate-400">Days</span>
                    </div>
                  )}
                </div>
              </div>

              <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsCreatingRfi(false)}
                  className="px-3 py-1.5 text-xs text-slate-400 hover:text-slate-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-semibold text-slate-900 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors"
                >
                  Issue Formal RFI
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
