import React, { useState } from 'react';
import { ChangeOrderItem, Project, RfiItem } from '../../types';
import { 
  DollarSign, 
  Search, 
  Plus, 
  Calendar, 
  AlertCircle, 
  CheckCircle2, 
  FileText, 
  Clock, 
  TrendingUp, 
  Calculator,
  ArrowRight
} from 'lucide-react';

interface ChangeOrderRegisterProps {
  changeOrders: ChangeOrderItem[];
  project: Project;
  rfis: RfiItem[];
  onAddChangeOrder: (newCo: ChangeOrderItem) => void;
  onUpdateChangeOrder: (updatedCo: ChangeOrderItem) => void;
}

export const ChangeOrderRegister: React.FC<ChangeOrderRegisterProps> = ({
  changeOrders,
  project,
  rfis,
  onAddChangeOrder,
  onUpdateChangeOrder,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [typeFilter, setTypeFilter] = useState<string>('All');
  const [selectedCo, setSelectedCo] = useState<ChangeOrderItem | null>(null);
  const [isCreatingCo, setIsCreatingCo] = useState(false);

  // New CO Form state with dynamic line-item markup calculation
  const [newTitle, setNewTitle] = useState('');
  const [newType, setNewType] = useState<ChangeOrderItem['type']>('PCO');
  const [newReason, setNewReason] = useState<ChangeOrderItem['reason']>('Design Revision');
  const [newDescription, setNewDescription] = useState('');
  const [newRfiRef, setNewRfiRef] = useState('');
  const [newScheduleDays, setNewScheduleDays] = useState(3);
  const [laborCost, setLaborCost] = useState(5400);
  const [materialsCost, setMaterialsCost] = useState(3800);
  const [equipmentCost, setEquipmentCost] = useState(1200);
  const [subcontractorCost, setSubcontractorCost] = useState(7500);
  const [markupPercent, setMarkupPercent] = useState(15);

  // Calculate live sum
  const subtotal = laborCost + materialsCost + equipmentCost + subcontractorCost;
  const markupAmount = (subtotal * markupPercent) / 100;
  const totalCalculated = subtotal + markupAmount;

  // Filtered COs
  const filteredCos = changeOrders.filter((co) => {
    const matchesSearch =
      co.number.toLowerCase().includes(searchTerm.toLowerCase()) ||
      co.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      co.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'All' || co.status === statusFilter;
    const matchesType = typeFilter === 'All' || co.type === typeFilter;
    return matchesSearch && matchesStatus && matchesType;
  });

  // Calculate high-level financial summary
  const approvedTotal = changeOrders
    .filter((co) => co.status === 'Approved')
    .reduce((sum, co) => sum + co.totalAmount, 0);

  const pendingTotal = changeOrders
    .filter((co) => co.status === 'Pending Review' || co.status === 'Draft')
    .reduce((sum, co) => sum + co.totalAmount, 0);

  const totalScheduleDaysAdded = changeOrders
    .filter((co) => co.status === 'Approved')
    .reduce((days, co) => days + co.scheduleDeltaDays, 0);

  const contingencyRemaining = project.contingencyBudget - approvedTotal;

  const handleSubmitNewCo = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const prefix = newType;
    const num = `${prefix}-0${changeOrders.length + 22}`;

    const newCo: ChangeOrderItem = {
      id: `co-${Date.now()}`,
      number: num,
      title: newTitle,
      type: newType,
      status: 'Pending Review',
      reason: newReason,
      description: newDescription,
      rfiReference: newRfiRef || undefined,
      dateCreated: new Date().toISOString().split('T')[0],
      scheduleDeltaDays: Number(newScheduleDays),
      breakdown: {
        labor: Number(laborCost),
        materials: Number(materialsCost),
        equipment: Number(equipmentCost),
        subcontractor: Number(subcontractorCost),
        markupPercent: Number(markupPercent),
      },
      totalAmount: totalCalculated,
      initiatedBy: 'Sarah Lin (Project Engineer)',
    };

    onAddChangeOrder(newCo);
    setIsCreatingCo(false);
    setSelectedCo(newCo);
    setNewTitle('');
    setNewDescription('');
  };

  const handleUpdateStatus = (co: ChangeOrderItem, newStatus: ChangeOrderItem['status']) => {
    const updated: ChangeOrderItem = {
      ...co,
      status: newStatus,
      dateResolved: newStatus === 'Approved' ? new Date().toISOString().split('T')[0] : co.dateResolved,
      approvedBy: newStatus === 'Approved' ? 'Arthur Vance (Owner Rep)' : co.approvedBy,
    };
    onUpdateChangeOrder(updated);
    setSelectedCo(updated);
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <span>Financials & Contracts</span>
            <span aria-hidden="true">·</span>
            <span>Change Orders</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono text-slate-300">{filteredCos.length} Records</span>
          </div>
          <h2 className="text-xl font-bold text-slate-100 mt-1">Cost Impact & Change Management</h2>
        </div>

        <button
          onClick={() => setIsCreatingCo(true)}
          className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-900 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors whitespace-nowrap shadow-sm self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>New Potential Change Order (PCO)</span>
        </button>
      </div>

      {/* Contract & Contingency Ledger Summary Bar */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
        <div className="p-3.5 bg-slate-900/80 border border-slate-800 rounded-lg">
          <div className="text-xs text-slate-400">Original Contract Sum</div>
          <div className="text-lg font-bold font-mono tabular-nums text-slate-100 mt-1">
            ${project.contractValue.toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">Base contract guaranteed max</div>
        </div>

        <div className="p-3.5 bg-slate-900/80 border border-slate-800 rounded-lg">
          <div className="text-xs text-emerald-400 font-medium">Approved Changes (OCO)</div>
          <div className="text-lg font-bold font-mono tabular-nums text-emerald-400 mt-1">
            +${approvedTotal.toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">
            Revised: ${(project.contractValue + approvedTotal).toLocaleString()}
          </div>
        </div>

        <div className="p-3.5 bg-slate-900/80 border border-slate-800 rounded-lg">
          <div className="text-xs text-amber-400 font-medium">Pending PCO Exposure</div>
          <div className="text-lg font-bold font-mono tabular-nums text-amber-400 mt-1">
            +${pendingTotal.toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">Under evaluation by owner</div>
        </div>

        <div className="p-3.5 bg-slate-900/80 border border-slate-800 rounded-lg">
          <div className="text-xs text-slate-400">Contingency Remaining</div>
          <div className="text-lg font-bold font-mono tabular-nums text-slate-100 mt-1">
            ${Math.max(0, contingencyRemaining).toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">
            Schedule delta: +{totalScheduleDaysAdded} days
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-3 bg-slate-900/60 border border-slate-800/80 rounded-lg">
        <div className="relative flex-1 min-w-[240px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search change order number, description, or reason..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-950 border border-slate-800 rounded-md text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-500/60"
          />
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <div className="flex items-center gap-1 p-0.5 bg-slate-950 border border-slate-800 rounded-md">
            {['All', 'Approved', 'Pending Review', 'Draft', 'Rejected'].map((status) => (
              <button
                key={status}
                onClick={() => setStatusFilter(status)}
                className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap ${
                  statusFilter === status
                    ? 'bg-slate-800 text-slate-100 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {status}
              </button>
            ))}
          </div>

          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="px-2.5 py-1.5 text-xs bg-slate-950 border border-slate-800 rounded-md text-slate-300 focus:outline-none cursor-pointer"
          >
            <option value="All">All Types (PCO / COR / OCO)</option>
            <option value="PCO">PCO (Potential Change Order)</option>
            <option value="COR">COR (Change Order Request)</option>
            <option value="OCO">OCO (Owner Change Order)</option>
          </select>
        </div>
      </div>

      {/* Change Orders Table */}
      <div className="border border-slate-800/80 rounded-lg bg-slate-900/40 overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-900/90 text-slate-400 border-b border-slate-800 uppercase font-mono tracking-wider text-[11px]">
              <tr>
                <th className="py-2.5 px-4 font-medium">Ref #</th>
                <th className="py-2.5 px-4 font-medium">Scope & Title</th>
                <th className="py-2.5 px-3 font-medium">Reason Code</th>
                <th className="py-2.5 px-3 font-medium">Status</th>
                <th className="py-2.5 px-3 font-medium">Schedule Impact</th>
                <th className="py-2.5 px-4 font-medium text-right">Cost Delta</th>
                <th className="py-2.5 px-3 font-medium text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {filteredCos.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-500">
                    No change orders found matching criteria.
                  </td>
                </tr>
              ) : (
                filteredCos.map((co) => (
                  <tr
                    key={co.id}
                    onClick={() => setSelectedCo(co)}
                    className="hover:bg-slate-800/40 transition-colors cursor-pointer group"
                  >
                    <td className="py-3 px-4 font-mono font-semibold text-slate-200 whitespace-nowrap">
                      {co.number}
                    </td>
                    <td className="py-3 px-4 max-w-sm">
                      <div className="font-medium text-slate-100 group-hover:text-amber-300 transition-colors truncate">
                        {co.title}
                      </div>
                      <div className="text-[11px] text-slate-400 truncate mt-0.5">
                        {co.description}
                      </div>
                    </td>
                    <td className="py-3 px-3 text-slate-300 whitespace-nowrap">
                      {co.reason}
                    </td>
                    <td className="py-3 px-3 whitespace-nowrap">
                      <span className={`text-xs font-medium ${
                        co.status === 'Approved' ? 'text-emerald-400' :
                        co.status === 'Pending Review' ? 'text-amber-400' :
                        co.status === 'Rejected' ? 'text-red-400' : 'text-slate-400'
                      }`}>
                        {co.status}
                      </span>
                    </td>
                    <td className="py-3 px-3 font-mono tabular-nums text-slate-300 whitespace-nowrap">
                      {co.scheduleDeltaDays > 0 ? `+${co.scheduleDeltaDays} Days` : '0 Days'}
                    </td>
                    <td className="py-3 px-4 font-mono tabular-nums text-right font-semibold whitespace-nowrap">
                      <span className={co.totalAmount < 0 ? 'text-emerald-400' : 'text-slate-100'}>
                        {co.totalAmount < 0 ? '-' : ''}${Math.abs(co.totalAmount).toLocaleString()}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right whitespace-nowrap">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedCo(co);
                        }}
                        className="px-2 py-1 text-slate-300 hover:text-white hover:bg-slate-800 rounded border border-slate-700/60 text-[11px]"
                      >
                        Itemize
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Change Order Breakdown Drawer / Modal */}
      {selectedCo && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-xl shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col overflow-hidden">
            <div className="p-4 border-b border-slate-800 flex items-start justify-between bg-slate-950">
              <div>
                <div className="flex items-center gap-2 text-xs text-slate-400 font-mono">
                  <span className="text-amber-400 font-bold">{selectedCo.number}</span>
                  <span>·</span>
                  <span>Type: {selectedCo.type}</span>
                  <span>·</span>
                  <span>Created {selectedCo.dateCreated}</span>
                </div>
                <h3 className="text-base font-semibold text-slate-100 mt-1">
                  {selectedCo.title}
                </h3>
              </div>
              <button
                onClick={() => setSelectedCo(null)}
                className="text-slate-400 hover:text-slate-100 p-1"
              >
                ✕
              </button>
            </div>

            <div className="p-5 overflow-y-auto space-y-4 text-xs text-slate-300">
              {/* Description */}
              <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg">
                <span className="text-slate-400 font-medium">Justification & Scope Description:</span>
                <p className="mt-1 text-slate-200 leading-relaxed font-sans">{selectedCo.description}</p>
                {selectedCo.rfiReference && (
                  <div className="mt-2 text-sky-400 text-[11px] font-mono">
                    Originating Reference: {selectedCo.rfiReference}
                  </div>
                )}
              </div>

              {/* Itemized Cost Sheet */}
              <div className="border border-slate-800 rounded-lg overflow-hidden bg-slate-950/60">
                <div className="p-2.5 bg-slate-950 border-b border-slate-800 font-semibold text-slate-200 flex justify-between">
                  <span>Itemized Cost Schedule</span>
                  <span className="text-slate-400 font-normal">AIA G701 Breakdown</span>
                </div>
                <div className="divide-y divide-slate-800/60 text-xs">
                  <div className="flex justify-between p-2.5">
                    <span className="text-slate-400">Direct Craft Labor</span>
                    <span className="font-mono text-slate-200">${selectedCo.breakdown.labor.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between p-2.5">
                    <span className="text-slate-400">Direct Materials & Fabrication</span>
                    <span className="font-mono text-slate-200">${selectedCo.breakdown.materials.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between p-2.5">
                    <span className="text-slate-400">Equipment Rental & Crane Time</span>
                    <span className="font-mono text-slate-200">${selectedCo.breakdown.equipment.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between p-2.5">
                    <span className="text-slate-400">Subcontractor Direct Costs</span>
                    <span className="font-mono text-slate-200">${selectedCo.breakdown.subcontractor.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between p-2.5 bg-slate-900/40">
                    <span className="text-slate-400">Contractor OH&P Markup ({selectedCo.breakdown.markupPercent}%)</span>
                    <span className="font-mono text-slate-300">
                      ${(((selectedCo.breakdown.labor + selectedCo.breakdown.materials + selectedCo.breakdown.equipment + selectedCo.breakdown.subcontractor) * selectedCo.breakdown.markupPercent) / 100).toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between p-3 bg-slate-900 text-sm font-bold text-slate-100">
                    <span>Total Cost Impact</span>
                    <span className="font-mono text-amber-400">${selectedCo.totalAmount.toLocaleString()}</span>
                  </div>
                </div>
              </div>

              {/* Status & Approval Actions */}
              <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg flex items-center justify-between">
                <div>
                  <div className="text-slate-400">Current Status: <strong className="text-slate-200">{selectedCo.status}</strong></div>
                  {selectedCo.approvedBy && (
                    <div className="text-[11px] text-emerald-400 mt-0.5">
                      Approved by {selectedCo.approvedBy} on {selectedCo.dateResolved}
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  {selectedCo.status !== 'Approved' && (
                    <button
                      onClick={() => handleUpdateStatus(selectedCo, 'Approved')}
                      className="px-3 py-1.5 text-xs font-semibold text-slate-900 bg-emerald-400 hover:bg-emerald-300 rounded transition-colors"
                    >
                      Approve Change Order
                    </button>
                  )}
                  {selectedCo.status !== 'Rejected' && (
                    <button
                      onClick={() => handleUpdateStatus(selectedCo, 'Rejected')}
                      className="px-3 py-1.5 text-xs font-medium text-red-400 hover:text-red-300 bg-red-950/60 hover:bg-red-900/60 border border-red-800/60 rounded transition-colors"
                    >
                      Reject
                    </button>
                  )}
                </div>
              </div>
            </div>

            <div className="p-3 border-t border-slate-800 bg-slate-950 flex items-center justify-end">
              <button
                onClick={() => setSelectedCo(null)}
                className="px-3 py-1.5 text-xs text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* New Change Order Modal */}
      {isCreatingCo && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-xl shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col overflow-hidden">
            <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950">
              <h3 className="text-base font-bold text-slate-100">Draft Potential Change Order (PCO)</h3>
              <button
                onClick={() => setIsCreatingCo(false)}
                className="text-slate-400 hover:text-slate-100 p-1"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmitNewCo} className="p-5 overflow-y-auto space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Change Order Title / Scope *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Additional conduit runs for solar string inverters at Sector C"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full p-2 text-xs bg-slate-950 border border-slate-800 rounded-md text-slate-200 focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Order Type</label>
                  <select
                    value={newType}
                    onChange={(e) => setNewType(e.target.value as any)}
                    className="w-full p-2 text-xs bg-slate-950 border border-slate-800 rounded-md text-slate-200 focus:outline-none focus:border-amber-500 cursor-pointer"
                  >
                    <option value="PCO">PCO - Potential Change Order</option>
                    <option value="COR">COR - Change Order Request</option>
                    <option value="OCO">OCO - Owner Directed Change</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Reason Code</label>
                  <select
                    value={newReason}
                    onChange={(e) => setNewReason(e.target.value as any)}
                    className="w-full p-2 text-xs bg-slate-950 border border-slate-800 rounded-md text-slate-200 focus:outline-none focus:border-amber-500 cursor-pointer"
                  >
                    <option value="Design Revision">Design Revision</option>
                    <option value="Unforeseen Field Condition">Unforeseen Field Condition</option>
                    <option value="Owner Scope Change">Owner Scope Addition</option>
                    <option value="Code Compliance">Code Compliance</option>
                    <option value="Value Engineering">Value Engineering Deduction</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Schedule Impact (Days)</label>
                  <input
                    type="number"
                    value={newScheduleDays}
                    onChange={(e) => setNewScheduleDays(Number(e.target.value))}
                    className="w-full p-2 text-xs bg-slate-950 border border-slate-800 rounded-md text-slate-200 focus:outline-none focus:border-amber-500 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Originating RFI (Optional)</label>
                  <select
                    value={newRfiRef}
                    onChange={(e) => setNewRfiRef(e.target.value)}
                    className="w-full p-2 text-xs bg-slate-950 border border-slate-800 rounded-md text-slate-200 focus:outline-none focus:border-amber-500"
                  >
                    <option value="">-- None --</option>
                    {rfis.map((r) => (
                      <option key={r.id} value={r.number}>
                        {r.number} - {r.title}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Detailed Description of Work</label>
                <textarea
                  rows={2}
                  placeholder="Detail cause of change, equipment mobilized, subcontractor quotes..."
                  value={newDescription}
                  onChange={(e) => setNewDescription(e.target.value)}
                  className="w-full p-2 text-xs bg-slate-950 border border-slate-800 rounded-md text-slate-200 focus:outline-none focus:border-amber-500"
                />
              </div>

              {/* Cost Inputs & Live Calculation */}
              <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg space-y-2">
                <div className="font-semibold text-slate-200 text-xs flex items-center gap-1.5">
                  <Calculator className="w-3.5 h-3.5 text-amber-400" />
                  <span>Cost Breakdown Calculator</span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  <div>
                    <label className="block text-[11px] text-slate-400">Labor ($)</label>
                    <input
                      type="number"
                      value={laborCost}
                      onChange={(e) => setLaborCost(Number(e.target.value))}
                      className="w-full p-1.5 text-xs bg-slate-900 border border-slate-700 rounded text-slate-200 font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-slate-400">Materials ($)</label>
                    <input
                      type="number"
                      value={materialsCost}
                      onChange={(e) => setMaterialsCost(Number(e.target.value))}
                      className="w-full p-1.5 text-xs bg-slate-900 border border-slate-700 rounded text-slate-200 font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-slate-400">Equipment ($)</label>
                    <input
                      type="number"
                      value={equipmentCost}
                      onChange={(e) => setEquipmentCost(Number(e.target.value))}
                      className="w-full p-1.5 text-xs bg-slate-900 border border-slate-700 rounded text-slate-200 font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-slate-400">Subcontractor ($)</label>
                    <input
                      type="number"
                      value={subcontractorCost}
                      onChange={(e) => setSubcontractorCost(Number(e.target.value))}
                      className="w-full p-1.5 text-xs bg-slate-900 border border-slate-700 rounded text-slate-200 font-mono"
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-800">
                  <div className="flex items-center gap-2">
                    <span className="text-slate-400 text-xs">OH&P Markup:</span>
                    <input
                      type="number"
                      value={markupPercent}
                      onChange={(e) => setMarkupPercent(Number(e.target.value))}
                      className="w-16 p-1 text-xs bg-slate-900 border border-slate-700 rounded text-slate-200 font-mono"
                    />
                    <span className="text-slate-400 text-xs">%</span>
                  </div>

                  <div className="text-right">
                    <span className="text-slate-400 text-xs">Total Proposal: </span>
                    <span className="text-sm font-bold font-mono text-amber-400">
                      ${totalCalculated.toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsCreatingCo(false)}
                  className="px-3 py-1.5 text-xs text-slate-400 hover:text-slate-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-semibold text-slate-900 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors"
                >
                  Issue Change Proposal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
