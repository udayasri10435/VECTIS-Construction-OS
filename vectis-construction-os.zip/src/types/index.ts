export type ProjectType = 'Commercial High-Rise' | 'Modular Volumetric' | 'Utility Solar & BESS' | 'Industrial BioTech';

export interface Project {
  id: string;
  name: string;
  code: string;
  type: ProjectType;
  client: string;
  location: string;
  contractValue: number;
  revisedContractValue: number;
  originalDurationDays: number;
  contingencyBudget: number;
  contingencyRemaining: number;
  completionPercent: number;
  weather: {
    temp: number;
    condition: string;
    windMph: number;
    humidity: number;
  };
}

export type RfiStatus = 'Draft' | 'Open' | 'Under Review' | 'Answered' | 'Closed';
export type RfiPriority = 'Low' | 'Medium' | 'High' | 'Critical';

export interface RfiItem {
  id: string;
  number: string; // e.g. RFI-104
  title: string;
  specSection: string; // e.g. "05 12 00 - Structural Steel Framing"
  drawingReference: string; // e.g. "S-201 / Detail 4"
  status: RfiStatus;
  priority: RfiPriority;
  assignedTo: string;
  assignedRole: string; // "Structural EOR", "MEP Consultant", "Architect of Record"
  ballInCourt: string;
  submittedBy: string;
  dateCreated: string;
  dateDue: string;
  dateClosed?: string;
  question: string;
  suggestedSolution: string;
  officialResponse?: string;
  respondedBy?: string;
  responseDate?: string;
  costImpact: boolean;
  costEstimate?: number;
  scheduleImpact: boolean;
  scheduleDays?: number;
  bimElementId?: string; // Linked 3D element
  gridReference: string; // e.g. "Grid C-4 / Level 2"
  attachmentsCount: number;
}

export type SubmittalStatus = 'Draft' | 'Submitted' | 'In Review' | 'Approved' | 'Approved as Noted' | 'Revise & Resubmit' | 'Rejected';
export type SubmittalType = 'Shop Drawings' | 'Product Data' | 'Material Sample' | 'Test Report' | 'LEED Verification';

export interface SubmittalItem {
  id: string;
  number: string; // e.g. SUB-08.11
  specDivision: string; // "03 - Concrete", "05 - Metals", "13 - Modular Units", "26 - Electrical"
  title: string;
  type: SubmittalType;
  revision: number;
  status: SubmittalStatus;
  leadTimeWeeks: number;
  requiredOnSiteDate: string;
  fabricator: string;
  reviewer: string;
  ballInCourt: string;
  dateSubmitted: string;
  dateApproved?: string;
  stampNote?: string;
  bimLinkedGuid?: string;
}

export type ChangeOrderType = 'PCO' | 'COR' | 'OCO'; // Potential Change Order, Change Order Request, Owner Change Order
export type ChangeOrderStatus = 'Draft' | 'Pending Review' | 'Architect Reviewed' | 'Approved' | 'Rejected' | 'Void';
export type ChangeOrderReason = 'Design Revision' | 'Unforeseen Field Condition' | 'Owner Scope Change' | 'Code Compliance' | 'Value Engineering';

export interface ChangeOrderItem {
  id: string;
  number: string; // e.g. PCO-024
  title: string;
  type: ChangeOrderType;
  status: ChangeOrderStatus;
  reason: ChangeOrderReason;
  description: string;
  rfiReference?: string;
  dateCreated: string;
  dateResolved?: string;
  scheduleDeltaDays: number;
  breakdown: {
    labor: number;
    materials: number;
    equipment: number;
    subcontractor: number;
    markupPercent: number; // e.g. 15%
  };
  totalAmount: number;
  initiatedBy: string;
  approvedBy?: string;
}

export interface DailyLogWeather {
  condition: 'Clear' | 'Partly Cloudy' | 'Rain' | 'High Winds' | 'Snow' | 'Extreme Heat';
  tempHigh: number;
  tempLow: number;
  windMph: number;
  precipitationInches: number;
  groundConditions: 'Dry & Firm' | 'Damp' | 'Muddy' | 'Standing Water' | 'Frozen';
  workHaltedDueToWeather: boolean;
}

export interface TradeCrewLog {
  id: string;
  trade: string;
  subcontractor: string;
  workersCount: number;
  hoursWorked: number;
  workDescription: string;
  locationArea: string;
}

export interface EquipmentLog {
  id: string;
  equipmentType: string;
  idTag: string;
  hoursActive: number;
  hoursIdle: number;
  status: 'Operational' | 'Standby' | 'Maintenance';
}

export interface DeliveryLog {
  id: string;
  material: string;
  supplier: string;
  quantity: string;
  deliveryTime: string;
  qaPassed: boolean;
  stagingBay: string;
}

export interface DailyLogPhoto {
  id: string;
  title: string;
  tag: 'Framing' | 'MEP Rough-in' | 'Modular Rigging' | 'Safety' | 'Concrete Pour';
  caption: string;
  time: string;
  verified: boolean;
}

export interface DailyLog {
  id: string;
  date: string;
  superintendent: string;
  shift: 'Day (07:00 - 15:30)' | 'Night (16:00 - 00:30)';
  weather: DailyLogWeather;
  generalNotes: string;
  laborCrews: TradeCrewLog[];
  equipment: EquipmentLog[];
  deliveries: DeliveryLog[];
  safetyTalkTopic: string;
  incidentsReported: boolean;
  incidentNotes?: string;
  photos: DailyLogPhoto[];
  signedBySuperintendent: boolean;
  signedAt?: string;
}

export interface BimElement {
  id: string;
  guid: string;
  name: string;
  category: 'structural' | 'mep' | 'modular_pod' | 'facade' | 'foundation';
  level: 'Sub-Grade' | 'Level 1' | 'Level 2' | 'Level 3' | 'Roof';
  grid: string; // e.g. "B-4"
  material: string;
  specs: string;
  fabricationStatus: 'Procured' | 'Fabricated' | 'In Transit' | 'Staged On-Site' | 'Erected' | 'Inspected';
  hasClash: boolean;
  clashDescription?: string;
  clashesWithGuid?: string;
  linkedRfiId?: string;
  linkedSubmittalId?: string;
  // Spatial bounding/mesh parameters for 3D procedural rendering
  position: [number, number, number];
  size: [number, number, number];
  color?: string;
}
