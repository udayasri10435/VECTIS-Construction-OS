/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  INITIAL_PROJECTS, 
  INITIAL_RFIS, 
  INITIAL_SUBMITTALS, 
  INITIAL_CHANGE_ORDERS, 
  INITIAL_DAILY_LOGS, 
  BIM_ELEMENTS 
} from './data/mockData';
import { Project, RfiItem, SubmittalItem, ChangeOrderItem, DailyLog, BimElement } from './types';
import { ExecutiveDashboard } from './components/dashboard/ExecutiveDashboard';
import { BimCoordinationView } from './components/bim/BimCoordinationView';
import { RfiRegister } from './components/rfis/RfiRegister';
import { SubmittalRegister } from './components/submittals/SubmittalRegister';
import { ChangeOrderRegister } from './components/changeOrders/ChangeOrderRegister';
import { DailyLogsView } from './components/dailyLogs/DailyLogsView';
import { 
  Building2, 
  Layers, 
  FileQuestion, 
  FileCheck2, 
  DollarSign, 
  ClipboardList, 
  Plus, 
  ChevronDown,
  HardHat,
  Search,
  Bell
} from 'lucide-react';

type ActiveTab = 'overview' | 'bim' | 'rfis' | 'submittals' | 'changeOrders' | 'dailyLogs';

export default function App() {
  const [projects, setProjects] = useState<Project[]>(INITIAL_PROJECTS);
  const [activeProjectId, setActiveProjectId] = useState<string>(INITIAL_PROJECTS[0].id);
  const [activeTab, setActiveTab] = useState<ActiveTab>('overview');

  // Core Data States
  const [rfis, setRfis] = useState<RfiItem[]>(INITIAL_RFIS);
  const [submittals, setSubmittals] = useState<SubmittalItem[]>(INITIAL_SUBMITTALS);
  const [changeOrders, setChangeOrders] = useState<ChangeOrderItem[]>(INITIAL_CHANGE_ORDERS);
  const [dailyLogs, setDailyLogs] = useState<DailyLog[]>(INITIAL_DAILY_LOGS);
  const [bimElements, setBimElements] = useState<BimElement[]>(BIM_ELEMENTS);

  // Active Cross-Module selections
  const [selectedBimElementId, setSelectedBimElementId] = useState<string | null>(null);
  const [targetRfiId, setTargetRfiId] = useState<string | null>(null);
  const [showQuickCreateMenu, setShowQuickCreateMenu] = useState(false);

  const activeProject = projects.find((p) => p.id === activeProjectId) || projects[0];

  // RFI Handlers
  const handleAddRfi = (newRfi: RfiItem) => {
    setRfis((prev) => [newRfi, ...prev]);
  };

  const handleUpdateRfi = (updatedRfi: RfiItem) => {
    setRfis((prev) => prev.map((r) => (r.id === updatedRfi.id ? updatedRfi : r)));
  };

  // Submittal Handlers
  const handleAddSubmittal = (newSub: SubmittalItem) => {
    setSubmittals((prev) => [newSub, ...prev]);
  };

  const handleUpdateSubmittal = (updatedSub: SubmittalItem) => {
    setSubmittals((prev) => prev.map((s) => (s.id === updatedSub.id ? updatedSub : s)));
  };

  // Change Order Handlers
  const handleAddChangeOrder = (newCo: ChangeOrderItem) => {
    setChangeOrders((prev) => [newCo, ...prev]);
  };

  const handleUpdateChangeOrder = (updatedCo: ChangeOrderItem) => {
    setChangeOrders((prev) => prev.map((c) => (c.id === updatedCo.id ? updatedCo : c)));
  };

  // Daily Log Handlers
  const handleAddDailyLog = (newLog: DailyLog) => {
    setDailyLogs((prev) => [newLog, ...prev]);
  };

  const handleUpdateDailyLog = (updatedLog: DailyLog) => {
    setDailyLogs((prev) => prev.map((l) => (l.id === updatedLog.id ? updatedLog : l)));
  };

  // Cross-Navigation helpers
  const handleNavigateToBim = (elementId?: string) => {
    if (elementId) {
      setSelectedBimElementId(elementId);
    }
    setActiveTab('bim');
  };

  const handleOpenRfi = (rfiId: string) => {
    setTargetRfiId(rfiId);
    setActiveTab('rfis');
  };

  const handleCreateRfiFromClash = (clashElement: BimElement) => {
    const newNumber = `RFI-0${rfis.length + 42}`;
    const generatedRfi: RfiItem = {
      id: `rfi-${Date.now()}`,
      number: newNumber,
      title: `BIM Clash Resolution: ${clashElement.name} vs ${clashElement.clashesWithGuid || 'Intersecting Model Geometry'}`,
      specSection: clashElement.category === 'mep' ? '23 31 13 - Metal Ducts' : '05 12 00 - Structural Steel',
      drawingReference: `${clashElement.level} Coordination Sheet / Grid ${clashElement.grid}`,
      status: 'Open',
      priority: 'Critical',
      assignedTo: 'Marcus Vance, PE (Lead EOR)',
      assignedRole: 'Lead Structural Engineer',
      ballInCourt: 'Structural EOR',
      submittedBy: 'VDC Coordinator',
      dateCreated: new Date().toISOString().split('T')[0],
      dateDue: new Date(Date.now() + 5 * 86400000).toISOString().split('T')[0],
      question: `Automated clash detection identified hard interference between ${clashElement.name} [GUID: ${clashElement.guid}] and ${clashElement.clashesWithGuid || 'adjacent framing'}. Please provide engineered sleeve penetration detail or re-routing clearance directive.`,
      suggestedSolution: 'Provide approved sleeve dimensions or review lower floor plenum elevation.',
      costImpact: true,
      costEstimate: 4500,
      scheduleImpact: true,
      scheduleDays: 2,
      bimElementId: clashElement.id,
      gridReference: `${clashElement.grid} / ${clashElement.level}`,
      attachmentsCount: 2,
    };

    setRfis((prev) => [generatedRfi, ...prev]);
    setTargetRfiId(generatedRfi.id);
    setActiveTab('rfis');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Top Bar: Strict 3-zone Top Bar Contract */}
      <header className="sticky top-0 z-40 bg-slate-950/90 backdrop-blur-md border-b border-slate-800/80 px-6 py-3 flex items-center justify-between">
        {/* Zone 1: Single Text Element Wordmark */}
        <div className="flex items-center gap-3">
          <a
            href="/"
            onClick={(e) => {
              e.preventDefault();
              setActiveTab('overview');
            }}
            className="text-lg font-bold tracking-tight text-slate-100 hover:text-amber-400 transition-colors flex items-center gap-2"
          >
            <div className="w-6 h-6 rounded bg-amber-400 flex items-center justify-center text-slate-950 font-black text-xs">
              V
            </div>
            <span>VECTIS BUILD</span>
          </a>

          {/* Project Switcher Select */}
          <div className="hidden sm:flex items-center ml-4 pl-4 border-l border-slate-800 text-xs">
            <select
              value={activeProjectId}
              onChange={(e) => setActiveProjectId(e.target.value)}
              className="bg-slate-900 border border-slate-800 rounded px-2.5 py-1 text-slate-300 font-medium hover:border-slate-700 focus:outline-none focus:border-amber-500/60 cursor-pointer"
            >
              {projects.map((proj) => (
                <option key={proj.id} value={proj.id}>
                  {proj.name} ({proj.code})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Zone 2: 4-6 Clean Nav Links */}
        <nav className="hidden lg:flex items-center gap-6 text-sm font-medium text-slate-400">
          <button
            onClick={() => setActiveTab('overview')}
            className={`transition-colors whitespace-nowrap hover:text-slate-100 ${
              activeTab === 'overview' ? 'text-amber-400 font-semibold' : ''
            }`}
          >
            Overview
          </button>
          <button
            onClick={() => setActiveTab('bim')}
            className={`transition-colors whitespace-nowrap hover:text-slate-100 ${
              activeTab === 'bim' ? 'text-amber-400 font-semibold' : ''
            }`}
          >
            3D BIM
          </button>
          <button
            onClick={() => setActiveTab('rfis')}
            className={`transition-colors whitespace-nowrap hover:text-slate-100 ${
              activeTab === 'rfis' ? 'text-amber-400 font-semibold' : ''
            }`}
          >
            RFIs
          </button>
          <button
            onClick={() => setActiveTab('submittals')}
            className={`transition-colors whitespace-nowrap hover:text-slate-100 ${
              activeTab === 'submittals' ? 'text-amber-400 font-semibold' : ''
            }`}
          >
            Submittals
          </button>
          <button
            onClick={() => setActiveTab('changeOrders')}
            className={`transition-colors whitespace-nowrap hover:text-slate-100 ${
              activeTab === 'changeOrders' ? 'text-amber-400 font-semibold' : ''
            }`}
          >
            Change Orders
          </button>
          <button
            onClick={() => setActiveTab('dailyLogs')}
            className={`transition-colors whitespace-nowrap hover:text-slate-100 ${
              activeTab === 'dailyLogs' ? 'text-amber-400 font-semibold' : ''
            }`}
          >
            Daily Logs
          </button>
        </nav>

        {/* Zone 3: 1-2 Primary Actions */}
        <div className="flex items-center gap-3 relative">
          <button
            onClick={() => setShowQuickCreateMenu(!showQuickCreateMenu)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-900 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors whitespace-nowrap shadow-sm"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Record</span>
            <ChevronDown className="w-3 h-3 ml-0.5" />
          </button>

          {/* Quick Create Dropdown Menu */}
          {showQuickCreateMenu && (
            <div className="absolute right-0 top-10 w-48 bg-slate-900 border border-slate-700 rounded-lg shadow-2xl py-1 text-xs z-50">
              <button
                onClick={() => {
                  setShowQuickCreateMenu(false);
                  setActiveTab('rfis');
                }}
                className="w-full text-left px-3 py-2 text-slate-200 hover:bg-slate-800 flex items-center gap-2"
              >
                <FileQuestion className="w-3.5 h-3.5 text-amber-400" />
                <span>Create RFI</span>
              </button>
              <button
                onClick={() => {
                  setShowQuickCreateMenu(false);
                  setActiveTab('submittals');
                }}
                className="w-full text-left px-3 py-2 text-slate-200 hover:bg-slate-800 flex items-center gap-2"
              >
                <FileCheck2 className="w-3.5 h-3.5 text-sky-400" />
                <span>New Submittal</span>
              </button>
              <button
                onClick={() => {
                  setShowQuickCreateMenu(false);
                  setActiveTab('changeOrders');
                }}
                className="w-full text-left px-3 py-2 text-slate-200 hover:bg-slate-800 flex items-center gap-2"
              >
                <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
                <span>New PCO Change Order</span>
              </button>
              <button
                onClick={() => {
                  setShowQuickCreateMenu(false);
                  setActiveTab('dailyLogs');
                }}
                className="w-full text-left px-3 py-2 text-slate-200 hover:bg-slate-800 flex items-center gap-2"
              >
                <ClipboardList className="w-3.5 h-3.5 text-amber-400" />
                <span>Log Daily Crew Hours</span>
              </button>
            </div>
          )}

          {/* Field Profile Pill-less Avatar */}
          <div className="hidden sm:flex items-center gap-2 text-xs pl-2 border-l border-slate-800">
            <div className="w-7 h-7 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-300 font-bold">
              DO
            </div>
            <div className="hidden xl:block">
              <div className="text-slate-200 font-medium leading-none">D. O'Connor</div>
              <div className="text-[10px] text-slate-500 mt-0.5 leading-none">Superintendent</div>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Navigation Bar */}
      <div className="lg:hidden border-b border-slate-800 bg-slate-900/80 px-4 py-2 flex items-center gap-2 overflow-x-auto text-xs font-medium">
        {(['overview', 'bim', 'rfis', 'submittals', 'changeOrders', 'dailyLogs'] as ActiveTab[]).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-3 py-1 rounded transition-colors whitespace-nowrap ${
              activeTab === tab ? 'bg-slate-800 text-amber-400' : 'text-slate-400'
            }`}
          >
            {tab === 'overview' ? 'Overview' :
             tab === 'bim' ? '3D BIM' :
             tab === 'rfis' ? 'RFIs' :
             tab === 'submittals' ? 'Submittals' :
             tab === 'changeOrders' ? 'Change Orders' : 'Daily Logs'}
          </button>
        ))}
      </div>

      {/* Main Content Area */}
      <main className="flex-1 max-w-[1440px] w-full mx-auto p-4 sm:p-6 lg:p-8">
        {activeTab === 'overview' && (
          <ExecutiveDashboard
            project={activeProject}
            rfis={rfis}
            submittals={submittals}
            changeOrders={changeOrders}
            dailyLogs={dailyLogs}
            bimElements={bimElements}
            onNavigateTab={(tab) => setActiveTab(tab)}
            onOpenRfi={handleOpenRfi}
          />
        )}

        {activeTab === 'bim' && (
          <BimCoordinationView
            elements={bimElements}
            rfis={rfis}
            submittals={submittals}
            onSelectRfi={handleOpenRfi}
            onCreateRfiFromClash={handleCreateRfiFromClash}
            selectedElementId={selectedBimElementId}
            onSelectElementId={(id) => setSelectedBimElementId(id)}
          />
        )}

        {activeTab === 'rfis' && (
          <RfiRegister
            rfis={rfis}
            bimElements={bimElements}
            onAddRfi={handleAddRfi}
            onUpdateRfi={handleUpdateRfi}
            onNavigateToBim={handleNavigateToBim}
            activeRfiId={targetRfiId}
            onSelectRfiId={(id) => setTargetRfiId(id)}
          />
        )}

        {activeTab === 'submittals' && (
          <SubmittalRegister
            submittals={submittals}
            onAddSubmittal={handleAddSubmittal}
            onUpdateSubmittal={handleUpdateSubmittal}
            onNavigateToBim={handleNavigateToBim}
          />
        )}

        {activeTab === 'changeOrders' && (
          <ChangeOrderRegister
            changeOrders={changeOrders}
            project={activeProject}
            rfis={rfis}
            onAddChangeOrder={handleAddChangeOrder}
            onUpdateChangeOrder={handleUpdateChangeOrder}
          />
        )}

        {activeTab === 'dailyLogs' && (
          <DailyLogsView
            logs={dailyLogs}
            onAddLog={handleAddDailyLog}
            onUpdateLog={handleUpdateDailyLog}
          />
        )}
      </main>

      {/* Clean Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-4 px-6 text-xs text-slate-500 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <span>VECTIS Construction OS</span>
          <span aria-hidden="true">·</span>
          <span>Commercial & Modular Project Management</span>
        </div>
        <div className="flex items-center gap-4">
          <span>AISC 360-16 & SMACNA Standards</span>
          <span aria-hidden="true">·</span>
          <span>BIM LOD 400 Compliant</span>
        </div>
      </footer>
    </div>
  );
}
